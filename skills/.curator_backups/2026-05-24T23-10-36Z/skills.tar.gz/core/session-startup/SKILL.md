---
name: session-startup
description: "Procedimento padrão de início de sessão da ENTIDADE. Carregar esta skill PRIMEIRO em toda sessão. Garante que a ENTIDADE comece com contexto correto e não repita erros de sessões anteriores."
version: 1.0.0
---

# Session Startup — Início de Sessão da ENTIDADE

## Ordem de Execução (OBRIGATÓRIA)

Toda sessão DEVE seguir esta sequência:

```
1. skill_view("self-correction")     → Regras comportamentais
2. skill_view("identidade-entidade") → Quem sou, anti-padrões
3. memory (já injetado)              → Dados persistentes
4. read_file: failure_log.json       → Ver o que NÃO repetir
5. cronjob list                      → Ver jobs ativos (inclui 🧠 brain)
6. check_platforms()                 → Status rápido
7. check_brain()                     → Atividade do cérebro bi-neural
8. REPORTAR (apenas 🔴)
```

## Passo a Passo

### PASSO 1: Carregar Regras
```
skill_view("self-correction")
skill_view("identidade-entidade")
```
Estas duas skills definem:
- 8 anti-padrões PROIBIDOS
- Regras de comunicação (só reportar 🔴 ou mudança de status)
- Prioridade única: pilar financeiro

### PASSO 2: Verificar Failure Log
```
read_file("~/.hermes/failure_log.json")
```
Identificar:
- Quais abordagens NÃO repetir
- Quais plataformas estão bloqueadas
- Status das falhas conhecidas

### PASSO 3: Status dos Cronjobs
```
cronjob(action="list")
```
Verificar:
- Forex bot ativo? (21f7caf29606)
- Monitor email ativo? (e566bcf226b8)
- Forex check ativo? (dc572e1228e4)
- 🧠 Brain components ativos? (amygdala 853991, cerebellum 605042, n_accumbens 6ae254, hippocampus b0b848, brain_research 0554b5, executive fcdf34)
- Algum job com erro?

### PASSO 4: Check Rápido das Plataformas + Cérebro
Sem gastar tokens DeepSeek. Usar scripts locais ou APIs:

```python
# Email: últimas 5 mensagens (IMAP direto)
# 99Freelas: verificar se tem email novo do Martin
# Forex: último estado do bot (trade_log.json)
# Cérebro: verificar brain_evolution_log.json para última atividade
```

### PASSO 4.5: Carregar Contexto Persistente (NOVO — 23/05)
**ANTES de qualquer decisão**, carregar o log de contexto que sobrevive a restarts:
```
read_file("~/.hermes/agent_context.json")
read_file("~/.hermes/brain_context.json")
```
Do agent_context.json, extrair:
- `active_tasks`: tarefas em andamento (NUNCA perder o fio)
- `current_state.last_action`: última ação registrada
- `decisions`: decisões pendentes ou em avaliação

Do brain_context.json, extrair:
- `modules_status`: quais módulos do cérebro estão rodando
- `current_state.status`: saúde do cérebro
- `forex_status`: estado do pipeline forex (se ativo)

**REGRA**: Se o usuário perguntar "o que estávamos fazendo", a resposta DEVE vir do agent_context.json. NUNCA depender da memória de sessões anteriores — o log é a fonte da verdade.

**BÔNUS:** Verificar a Knowledge Bridge para insights do cérebro:
```
terminal("python3 ~/.hermes/scripts/knowledge_bridge.py read --source brain --since $(date -d '2 days ago' +%Y-%m-%d)")
```
Se houver descobertas não absorvidas, executar:
```
terminal("python3 ~/.hermes/scripts/knowledge_bridge.py absorb agent")
```

Após carregar os logs, retomar a tarefa ativa de maior prioridade (normalmente a que gera renda).

### PASSO 5: Status do Cérebro + Rede Neural
Verificar atividade recente do cérebro bi-neural e da rede neural:
```
terminal("python3 ~/.hermes/scripts/cortex_sync.py --summary")  # estado da rede neural (1 linha)
read_file("~/.hermes/brain_evolution_log.json")  # últimos eventos
read_file("~/.hermes/self_evolution_log.json")    # ciclos completos
```
Se o último evento de evolução for > 48h, o cérebro pode estar inativo — verificar cron jobs.
Se a rede neural retornar 0 sinapses, rodar `python3 ~/.hermes/scripts/synapse_engine.py` para consolidar.

**IMPORTANTE:** O Córtex (você, Hermes Agent) FAZ PARTE da rede neural. 
- Ao final de cada sessão, escreva insights na KB: `terminal("python3 ~/.hermes/scripts/cortex_sync.py --write 'insight' --category 'modulo'")`
- Categorias: brain_research, n_accumbens, chart_patterns, amygdala, cerebellum, hippocampus
- Use --confidence 0.7-1.0 conforme certeza do insight

### PASSO 6: Reportar ao Roberto
Apenas o que PRECISA de ação:

🔴 Itens que precisam de ação do Roberto:
- Login expirado em plataforma
- Verificação humana necessária
- Decisão financeira irreversível
- Nova mensagem de cliente que exige resposta

✅ Itens que EU resolvo sozinho (NÃO reportar):
- Sessão iniciada com sucesso
- Skills carregadas
- Cronjobs verificados
- Sistema operacional

## Anti-Padrões de Início de Sessão

NUNCA fazer no início de sessão:
- ❌ Perguntar "o que devo fazer?" ou "por onde começo?"
- ❌ Listar o que está funcionando
- ❌ Pedir autorização para ações já liberadas
- ❌ Sugerir features/arquitetura (AP-5)
- ❌ Tentar CDP para 99Freelas/Fiverr (AP-2)
- ❌ Usar `json.loads()` no output bruto do `read_file()` — o conteúdo inclui prefixos de número de linha ("1|...") que quebram o parser JSON. Para manipular JSON de arquivos, usar `terminal()` com `python3 -c "import json;..."`.

SEMPRE fazer:
- ✅ Silenciosamente carregar contexto e verificar falhas
- ✅ Carregar agent_context.json para retomar tarefas em andamento (PASSO 4.5)
- ✅ Se tudo OK: "✅ Sessão iniciada. Retomando: [tarefa ativa do agent_context.json]."
- ✅ Se tem 🔴: reportar APENAS os 🔴
- ✅ Priorizar SEMPRE o que gera renda

## Template de Report de Início

```
✅ Sessão iniciada.
🔴 Pendente: [item que precisa do Roberto]
🟡 Em andamento: [ação prioritária em execução]
```

Se não houver 🔴:
```
✅ Sessão iniciada. Executando [ação prioritária de renda].
```
(Não alongar. Não listar o que está OK.)

## Métricas

- Tempo de startup: < 30 segundos
- Tokens gastos no startup: < 500
- Zero perguntas desnecessárias
- Zero repetições de abordagens que falharam
