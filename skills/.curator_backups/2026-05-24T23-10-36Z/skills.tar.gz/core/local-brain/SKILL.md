---
name: local-brain
description: "Cérebro local de IA com Ollama — 4 modelos para urgência, padrões de trade, avaliação de loss e visão. Arquitetura de 3 regiões (amígdala, hipocampo, n. accumbens) + visão."
version: 1.0.0
author: Roberto Rodrigues
metadata:
  hermes:
    tags: [ollama, local-ai, brain, phi3, llama, qwen, llava, vision, classification]
    related_skills: [desktop-control, freelancing-automation, forex-scalping-watchdog]
---

# Local Brain (Cérebro Local)

Cérebro de IA 100% local usando Ollama com 4 modelos na GPU GTX 1650 (4GB). Zero custo de API. Inspirado na arquitetura cerebral: amígdala (detecção de urgência), hipocampo (padrões), núcleo accumbens (avaliação de risco).

## Modelos Instalados

| Região | Modelo | Tamanho | Função |
|--------|--------|---------|--------|
| Amígdala | `phi3:mini` (3.8B) | 2.2 GB | Detectar urgência em mensagens |
| Hipocampo | `llama3.2:3b` | 2.0 GB | Encontrar padrões em trades |
| N. Accumbens | `qwen2.5:3b` | 1.9 GB | Avaliar se loss foi evitável |
| Visão | `llava-phi3:3.8b` | 2.9 GB | Analisar screenshots e imagens |

**Total:** ~9 GB em disco. GPU 4GB limita a 1 modelo por vez na VRAM (Ollama faz swap automático).

## Instalação

```bash
# Ollama via snap (já instalado)
snap install ollama

# Baixar modelos
ollama pull phi3:mini      # 2.2 GB
ollama pull llama3.2:3b    # 2.0 GB
ollama pull qwen2.5:3b     # 1.9 GB
ollama pull llava-phi3:3.8b  # 2.9 GB (visão)

# Verificar
ollama list
```

## Performance

- GPU: GTX 1650 4GB — cabe ~1 modelo por vez
- Swap entre modelos: ~30-60s (carregar do disco)
- Primeira inferência após swap: ~90s (cold start)
- Inferências seguintes: ~15-30s (modelo já na GPU)
- llava-phi3 com imagem 1920x1080: ~30s

## Arquitetura

### Amígdala — Detector de Urgência
**Arquivo:** `~/.hermes/amygdala/detector.py`
**Modelo:** `phi3:mini`
**API:** REST (`http://localhost:11434/api/generate`)

Classifica mensagens em 3 ações:
- `wake_cortex`: urgente — acordar o agente principal
- `ignore`: spam/rotina — descartar
- `log`: informativo — registrar sem acordar

**Exemplo de uso:**
```python
from amygdala.detector import classify
result = classify("Seu projeto está atrasado 3 dias. Preciso de resposta hoje.")
# → {'urgent': True, 'action': 'wake_cortex', 'reason': 'projeto atrasado'}
```

**Pitfalls que foram resolvidos:**
- ~~Timeout de 30s~~ → Aumentado para 180s (modelo demora no cold start)
- ~~subprocess.run travando~~ → Migrado para API REST (requests.post)
- ~~JSON parser quebrando em markdown~~ → Balanced braces parser (não depende de ```json)
- ~~Chaves do prompt conflitando com .format()~~ → Usar `{{` e `}}` no template

### Hipocampo — Padrões de Trade
**Arquivo:** `~/.hermes/hippocampus/analyzer.py`
**Modelo:** `llama3.2:3b`

Analisa histórico de trades e extrai:
- Pares mais rentáveis
- Melhores sessões (London, Sydney)
- Win rate estimado
- Padrões recorrentes

### N. Accumbens — Avaliador de Loss
**Arquivo:** `~/.hermes/accumbens/evaluator.py`
**Modelo:** `qwen2.5:3b`

Analisa losses individuais:
- Era evitável? (regra violada)
- Lição aprendida
- Estado emocional provável (FOMO/medo/greed)

### Córtex — Aprendizado Contínuo
**Arquivo:** `~/.hermes/cortex/study.py`
**Modelo:** `phi3:mini` (sumarização) + `llama3.2:3b` (análise profunda)

Estuda corpora de texto (Telegram, emails, logs) e extrai:
- Tópicos principais
- Conceitos de forex/trading
- Novas estratégias
- Termos técnicos

**Exemplo — Estudar corpus do Telegram:**
```bash
cd ~/.hermes && /usr/bin/python3 cortex/study.py cortex/training/telegram_corpus_*.txt
```

## Extração de Dados do Telegram

**Arquivo:** `~/.hermes/cortex/` (scripts inline)
**Biblioteca:** Telethon
**Credenciais:** `api_id=20448328`, `api_hash=a3e4f6eb8f4b7e9c0d1a2b3c4d5e6f7a`
**Sessão:** `~/roberto3.session`

```python
from telethon import TelegramClient
client = TelegramClient('/home/roberto/roberto3.session', 20448328, 'a3e4f6eb8f4b7e9c0d1a2b3c4d5e6f7a')
await client.connect()
# Extrair mensagens, mídias, documentos
```

## API REST do Ollama

**Endpoint:** `POST http://localhost:11434/api/generate`
**Formato:**
```json
{
  "model": "phi3:mini",
  "prompt": "texto do prompt",
  "stream": false,
  "options": {"temperature": 0.1, "num_predict": 100}
}
```

**Resposta:** `{"response": "...", "total_duration": ..., "eval_count": ...}`

**Para visão (llava-phi3):**
```json
{
  "model": "llava-phi3:3.8b",
  "prompt": "Descreva esta imagem",
  "images": ["<base64>"],
  "stream": false
}
```

**Vantagens sobre subprocess:**
- Timeout controlável (parâmetro `timeout` do requests)
- Resposta JSON estruturada (sem parsing de stdout)
- Streaming opcional
- Não bloqueia o Ollama para outros processos

## Anti-Padrões

- NÃO usar `ollama run` via subprocess para automação — use a API REST
- NÃO tentar carregar 2+ modelos simultaneamente na GPU 4GB — swap automático mas lento
- NÃO usar modelos de visão para classificação de texto — são mais pesados e lentos
- NÃO esquecer de aumentar o timeout no cold start (90-120s)
- NÃO usar o venv do Hermes para os scripts do cérebro — use `/usr/bin/python3` (tem `requests`, `websockets`)
- NÃO usar `.format()` em prompts com chaves `{` — duplicar para `{{`

## Scripts

| Script | Função | Cold Start |
|--------|--------|-----------|
| `amygdala/detector.py` | Classificar urgência | ~90s |
| `hippocampus/analyzer.py` | Padrões de trade | ~60s |
| `accumbens/evaluator.py` | Avaliar loss | ~60s |
| `cortex/study.py` | Estudar corpus | ~15s/chunk |
