---
name: cortex-system
description: "Sistema de córtices cerebrais da ENTIDADE — visão computacional, áudio, controle motor e roteamento de eventos. Arquitetura bi-neural com Tálamo + córtices especializados."
version: 1.0.0
author: Roberto Rodrigues
license: MIT
metadata:
  hermes:
    tags: [cortex, vision, audio, motor, thalamus, brain, neural, bi-neural]
    related_skills: [architecture, life-os, financial-intelligence, automation]
---

# Cortex System — Sistema Nervoso Artificial

O sistema de córtices implementa uma arquitetura inspirada no cérebro humano.
Cada módulo é um córtex especializado — independente, Python puro, zero dependências externas.
O Tálamo é o router central que filtra e classifica todo input antes de chegar ao Córtex Pré-Frontal (Hermes Agent).

## MÓDULOS

### 🧠 Tálamo — Router Central
**Local:** `~/.hermes/thalamus/`

Filtra TODO input antes de chegar ao Córtex. Classifica por tipo (FINANCE, SOCIAL, SYSTEM, CORTEX, SPAM) e urgência (L1-L3). Decide se o Hermes Agent precisa ser acordado.

```
[Qualquer input] → Tálamo → classifica → L3 urgente? acorda Hermes
                                     → L1 normal? descarta/silencia
```

**Arquivos:**
- `router.py` — Core, API: `Thalamus().route(source, raw_input, metadata)`
- `schema.py` — Formato canônico `Event` com enums
- `filters.py` — Pipeline de 8 filtros com keyword scoring

### 👁️ Visual Cortex — Visão Computacional
**Local:** `~/.hermes/cortex/visual.py`

Captura screenshots, OCR, detecção de elementos na tela. Usa Xvfb para apps Wine (MT5), CDP para browser, e D-Bus/mss para desktop.

**API principal:**
```python
from cortex.visual import VisualCortex
vc = VisualCortex()
path = vc.see('mt5')          # Screenshot do MT5
text = vc.read(path)          # OCR do screenshot
regions = vc.find('EURUSD', path)  # Encontrar texto na tela
vc.focus('MetaTrader')        # Focar janela
vc.click(500, 400)            # Clicar em coordenadas
```

**Limitação conhecida:** Wayland GNOME bloqueia screenshots do desktop real. Xvfb funciona para Wine/MT5. OCR em fontes Wine-renderizadas tem baixa acurácia (anti-aliasing).

### 👂 Audio Cortex — Processamento de Áudio
**Local:** `~/.hermes/cortex/audio.py`

Captura de microfone, transcrição (Whisper), análise de som.

**API principal:**
```python
from cortex.audio import AudioCortex
ac = AudioCortex()
audio = ac.hear(5)              # Gravar 5 segundos
result = ac.understand(audio)   # Transcrever
result = ac.listen_once(5)      # Gravar + transcrever em 1 chamada
```

### 🦾 Motor Cortex — Execução de Ações
**Local:** `~/.hermes/cortex/motor.py`

Controle fino de mouse, teclado, janelas. Expansão do `mt5_direct.py` para qualquer software.

**API principal:**
```python
from cortex.motor import MotorCortex
mc = MotorCortex()
mc.focus('MetaTrader')          # Focar janela
mc.press('ctrl+t')              # Atalho de teclado
mc.type('GBPUSD')               # Digitar texto
mc.move(500, 400)               # Mover mouse
mc.click(500, 400)              # Clicar
mc.trade('EUR/USD', 'BUY', 1.16279, 2.0, 5.0)  # Executar trade CHoCH+FVG
mc.close_all()                  # Fechar todas posições MT5
mc.app('mt5', 'f9')             # Ação pré-definida (New Order)
```

## INTEGRAÇÃO COM O TÁLAMO

Todo evento dos córtices deve passar pelo Tálamo:
```python
from thalamus.router import route
event = route('cortex', 'trade_executado', metadata={'pair': 'EUR/USD', 'pnl': 9.7})
# → event.type=FINANCE, event.urgency=L3, event.should_wake=True
```

## ARQUITETURA BI-NEURAL

```
SENSORES (Visual, Audio, Sistema, Mercado)
          ↓
      TÁLAMO (filtro, classificação, priorização)
          ↓
   CÓRTEX PRÉ-FRONTAL (Hermes Agent — raciocínio, decisão, comunicação)
          ↓
   CÓRTEX MOTOR (execução: trades, mensagens, controle de software)
```

## PITFALLS

- **Wayland bloqueia screenshots do desktop.** GNOME não expõe wlr-screencopy. Workaround: Xvfb para Wine/MT5, CDP para browser.
- **NVIDIA Optimus não expõe fan control.** nvidia-settings não controla fans em laptops com GPU híbrida. Fans são gerenciadas pela BIOS/EC.
- **OCR em Wine é limitado.** Fontes anti-aliased do Wine têm baixa acurácia no Tesseract. Upscaling ajuda marginalmente.
- **Python do venv (3.11) não tem OpenCV.** Os córtices usam `/usr/bin/python3` (3.14) que tem todos os pacotes. Usar `#!/usr/bin/env python3` no shebang.
- **Cloudflare Turnstile bloqueia login automatizado.** O 99Freelas usa Turnstile que requer interação humana (checkbox). Workaround: login manual 1x → cookies persistem → injetar na sessão CDP.

## DEPENDÊNCIAS (todas instaladas)

Sistema: tesseract-ocr, xdotool, ffmpeg
Python 3.14: mss, pynput, opencv-python-headless, pytesseract, Pillow, numpy, yfinance
Opcional: pyaudio (para Audio Cortex), faster-whisper (para transcrição)

## References
- **[ubuntu-hardware-control.md](references/ubuntu-hardware-control.md)** — Comandos de controle de hardware Ubuntu (CPU, GPU, fans, NVIDIA driver)
