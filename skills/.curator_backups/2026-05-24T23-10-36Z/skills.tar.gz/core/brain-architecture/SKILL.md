---
name: brain-architecture
description: "Arquitetura cognitiva multi-agente da ENTIDADE — mapeamento cérebro→subagentes, Tálamo (message router), Amígdala (urgência), Digital Twin, design de novos agentes cognitivos."
version: 1.1.0
metadata:
  hermes:
    tags: [brain, cognitive, multi-agent, thalamus, digital-twin, architecture]
    related_skills: [architecture, life-os, operational-intelligence, financial-intelligence, system-health]
---

# Brain Architecture — Cérebro Bi-Neural da ENTIDADE

**brain-architecture é a skill primária do conjunto cerebral. Autoridade definida em `~/.hermes/brain_governance.md`.**

Arquitetura cognitiva inspirada no cérebro humano. Cada região cerebral = um sub-agente especializado. Hermes Agent = Córtex Pré-Frontal (núcleo decisor).

## MAPEAMENTO CEREBRAL

### Sistema Sensorial (Input)

| Região Cerebral | Agente | Função | Fonte de Dados |
|----------------|--------|--------|----------------|
| Córtex Visual (Occipital) | `chart-vision`, `browser-eye` | Gráficos forex, DOM, screenshots | MT5, browser CDP |
| Córtex Auditivo (Temporal) | `audio-transcriber` | Voz → texto | Telegram/WhatsApp áudio |
| Somatossensorial (Parietal) | `system-health`, `market-pulse` | CPU/RAM/disco, preço real-time | psutil, yfinance |

### Sistema de Retransmissão (Gateway)

| Região | Componente | Função |
|--------|-----------|--------|
| **Tálamo** | `~/.hermes/thalamus/router.py` | Filtra e classifica TODO input. Decide o que chega ao Córtex. |
| Formação Reticular | `monitor.py`, `forex_check.py` | Scripts no_agent que só acordam o sistema com alerta real |

### Sistema Límbico (Memória/Prioridade)

| Região | Agente | Função |
|--------|--------|--------|
| **Amígdala** | `threat-detector` | Classifica urgência: "Isso é grave?" |
| **Hipocampo** | `memory-consolidator` | Consolida padrões, trade history, memória semanal |
| **N. Accumbens** | `reinforcement-learner` | Aprende com WIN/LOSS, ajusta scores de pares forex |

### Córtex Pré-Frontal (Executivo = Hermes Agent)

| Sub-região | Função |
|-----------|--------|
| Dorsolateral PFC | Working memory, planejamento, decomposição de tarefas |
| Orbitofrontal PFC | Decisão, avaliação risco/recompensa |
| Cíngulo Anterior | Detecção de erro, resolução de conflito entre agentes |

### Sistema Motor (Output)

| Região | Agente | Ação |
|--------|--------|------|
| Córtex Motor | `mt5-executor`, `telegram-sender`, `email-sender` | Executa trades, envia mensagens |
| Cerebelo | `trade_closer.py`, validação pós-ação | Feedback loop: "A ação realmente aconteceu?" |
| Tronco Cerebral | Cron jobs essenciais | Health check, resiliência, memory consolidation |

## TÁLAMO — MESSAGE ROUTER

O Tálamo é a primeira linha de defesa. NADA chega ao Córtex sem passar por ele.

### Localização
```
~/.hermes/thalamus/
├── __init__.py      # Package init
├── schema.py        # Formato Event + enums (EventType, Urgency, Source)
├── filters.py       # Pipeline de 8 filtros com keyword scoring
└── router.py        # Core: Thalamus class + route()
```

### API
```python
from thalamus.router import route

event = route("email", "Problema no saque", metadata={"from": "cliente@x.com"})
# → event.type=FINANCE, event.urgency=L3, event.should_wake=True
```

### Pipeline de Classificação

| Filtro | EventType | Urgency | Wake Córtex? |
|--------|-----------|---------|-------------|
| Spam | SPAM | L1 | ❌ descartado |
| **Error sanitization (v2.1)** | **SPAM** | **L1** | **❌ descartado (injection bloqueada)** |
| Trade executado | FINANCE | L3 | ✅ |
| Erro crítico sistema | SYSTEM | L3 | ✅ |
| Email de cliente | SOCIAL | L2 | ✅ |
| Warning sistema | SYSTEM | L2 | ✅ |
| Alerta forex | FINANCE | L1/L2 | varia |
| Health check OK | SYSTEM | L1 | ❌ ignorado |
| Newsletter | SOCIAL | L1 | ❌ ignorado |

### Log
`~/.hermes/thalamus/event_log.json` — array JSON com todos os eventos, limitado a 100k entradas.

## DIGITAL TWIN — EVOLUÇÃO CONTÍNUA

Arquitetura preparada para integrar dados de smartphone, smartwatch, VR e dispositivos futuros.

### Princípio Plug-and-Play
```
[DISPOSITIVO] → [SENSOR AGENT] → [TÁLAMO] → [CÓRTEX]
                                       ↑
                            classifica por tipo, urgência, relevância
                            independente da origem
```

### Dispositivos Mapeados

| Dispositivo | Dados | Status |
|------------|-------|--------|
| 📱 Smartphone | Tempo de tela, localização, notificações, chamadas | Futuro |
| ⌚ Smartwatch | FC, HRV, SpO2, sono, passos | Futuro |
| 🥽 VR/AR | Eye tracking, atenção, postura | Futuro |
| 💻 PC | Browser, logs, métricas | ✅ Atual |
| 📧 Email | Volume, remetentes, tom | ✅ Atual |
| 💬 Chat | Telegram, WhatsApp | ✅ Atual |

### Camadas de Coaching

| Nível | Tipo | Exemplo |
|-------|------|---------|
| N1 — Consciência | Insight passivo | "Você passou 18h no Instagram esta semana" |
| N2 — Nudge | Sugestão no momento | "São 23:30 e você está no Instagram há 40min" |
| N3 — Intervenção | Bloqueio + redirecionamento | Bloquear app após cota diária |

## DESIGN DE NOVOS AGENTES

### Template para Criar um Agente Cognitivo

1. **Identificar a região cerebral correspondente** (qual função cognitiva?)
2. **Definir formato de evento** (schema.py)
3. **Adicionar filtro no Tálamo** (filters.py) — como classificar esse input?
4. **Criar script no_agent** se for monitoramento passivo (zero tokens)
5. **Criar cron job** para execução periódica
6. **Conectar ao Córtex** — o que deve acordar o Hermes Agent?

### Agentes Implementados (23/05/2026)

| Região | Script | Cron Job | Schedule | Status |
|--------|--------|----------|----------|--------|
| **Amígdala** | `scripts/amygdala.py` | `853991c6f44b` | */15 min | ✅ Ativo |
| **N. Accumbens** | `scripts/n_accumbens.py` | `6ae254c0b104` | 18:30 seg-sex | ✅ Ativo |
| **Hipocampo** | `scripts/hippocampus.py` | `b0b848ba83d1` | Dom 10:00 | ✅ Ativo |
| **Cerebelo v2.1** | `scripts/cerebellum.py` | `6050427dfccd` | */5 min seg-sex | ✅ Ativo |
| **Brain Research** | `scripts/brain_research.py` | `0554b5690934` | 06:30 diário | ✅ Ativo |
| **Executive v2** | `executive/brain.py` | `fcdf34b789c0` | */5 min seg-sex | ✅ Ativo |
| **Code Validator** (AP-12) | `scripts/brain_code_validator.py` | — | sob demanda | ✅ Novo |

Todos os scripts são **no_agent** — zero tokens. Output via `~/.hermes/cron/output/<component>/`.

### Pendentes
- [ ] **Audio-transcriber** — voz → texto para Telegram/WhatsApp
- [ ] **Digital Twin devices** — smartphone, smartwatch, VR integration
- [x] ~~**Browser interno** — Brave CDP headless :9223 (systemd hermes-brain-browser, controller scripts/brain_browser.py)~~
- [x] ~~**TradingView** — logado Google OAuth, fonte primária de dados forex, Bar Replay funcional~~
- [x] ~~**Chart Visual Learner** — ativar quando MT5 reconectar no Xvfb :99~~

### Novos Componentes (23/05)

| Componente | Script | Função |
|-----------|--------|--------|
| **Brain Browser** | `scripts/brain_browser.py` | Navegador CDP para scripts do cérebro (navigate, content, screenshot, eval) |
| **Chart Analyzer** | `scripts/tv_chart_analyzer.py` | Controle do TradingView: pairs, Bar Replay, screenshots, OHLC |
| **Chart Scanner** | `scripts/tv_chart_scanner.sh` | Cron */30 min: screenshot automático de 5 pares M15 |
| **Degraded Learner** | `scripts/chart_pattern_degraded.py` | Estudo offline: templates numéricos, similaridade cross-pattern, archetypes |
| **FVG Simulation** | `scripts/fvg_simulation.py` | Backtest massivo de FVG em qualquer par com filtros configuráveis |

## FEATURE ABSORPTION PROTOCOL — Absorver Capacidades de Ferramentas Externas

Quando o Hermes Agent lança uma nova versão com features absorvidas de ferramentas externas
(Claude Code, Codex, OpenCode, ruff, etc.), o cérebro deve absorvê-las também. Este protocolo
define COMO fazer isso de forma sistemática.

### Passo a Passo

1. **Identificar** — `grep -i "claude\|ruff\|inspired\|absorb" RELEASE_v*.md` no repo do Hermes.
   Encontrar features explicitamente creditadas a ferramentas externas.

2. **Mapear para região cerebral** — qual componente do cérebro lida com essa classe de problema?

| Tipo de Feature | Região Cerebral | Arquivo |
|----------------|----------------|---------|
| Segurança de comandos | **Cerebelo** (validação) | `scripts/cerebellum.py` |
| Filtro/sanitização de input | **Tálamo** (router) | `thalamus/filters.py` |
| Validação de código/sintaxe | **Brain Code Validator** | `scripts/brain_code_validator.py` |
| Aprendizado/reforço | **N. Accumbens** | `scripts/n_accumbens.py` |
| Memória/padrões | **Hipocampo** | `scripts/hippocampus.py` |
| Urgência/threat | **Amígdala** | `scripts/amygdala.py` |
| Execução/ação | **Córtex Motor** | `cortex/motor.py` |

3. **Implementar** — código Python puro, zero tokens, zero dependências novas.
   Adicionar a função/validação no script existente. Não criar script novo a menos que
   seja uma capacidade totalmente nova (ex: `brain_code_validator.py`).

4. **Adicionar anti-padrão** no `self-correction` (AP-NN) para evitar regressão comportamental.

5. **Atualizar skills** — `brain-architecture`, `bi-neural-brain`, `self-correction`.

6. **Documentar** — criar `references/brain-vX.Y-upgrade.md` com o que foi absorvido,
   de onde veio, e o impacto.

7. **Validar** — rodar o script modificado (`python3 scripts/cerebellum.py`), verificar
   que não quebrou, rodar `brain_code_validator.py --all`.

### Exemplo: Upgrade v2.1 (23/05/2026)

| Absorção | Origem | Feature Hermes | Aplicado ao Cérebro |
|----------|--------|---------------|-------------------|
| Dangerous command detection | Claude Code | "3 bypasses closed" | Cerebelo: 13 padrões regex |
| Error sanitization | Claude Code | "tool-error sanitization" | Tálamo: filter_error_sanitization (pos 2) |
| LSP semantic diagnostics | ruff | "LSP diagnostics on write_file/patch" | Brain Code Validator: AST validation |

### Pitfalls

- NÃO criar dependências externas (ruff CLI, LSP servers) — usar Python stdlib (ast, re)
- NÃO usar tokens — implementações são scripts no_agent
- NÃO duplicar filtros — se o Tálamo já tem um filtro similar, estender, não criar outro
- SEMPRE rodar `brain_code_validator.py --all` depois de modificar scripts

## ARQUITETURA DE COMUNICAÇÃO (v2.0)

```
[SENSORES] → Tálamo (filtro) → Amígdala (urgente?) → Hipocampo (padrão similar?)
                                          ↓
                                   [CÓRTEX = HERMES AGENT]
                                          ↓
                                    Decisão + Ação
                                          ↓
                                   Cerebelo (validar)
                                          ↓
                              ═══════════════════════
                              REDE NEURAL (Synapse Engine)
                              conhecimento compartilhado
                              entre TODOS os módulos
                              ═══════════════════════
```

> **Nota:** O `bi-neural-brain` é a skill autoritativa com a lista completa de componentes,
> cron jobs, e a arquitetura da Rede Neural (Synapse Engine + Neural KB).
> Esta skill (`brain-architecture`) cobre a teoria do mapeamento cerebral e o design
> de novos agentes. Consulte `bi-neural-brain` para o estado operacional atual.

## GOVERNAÇÃO DO CÉREBRO

Documento completo: `~/.hermes/brain_governance.md`

### Hierarquia de Autoridade

```
ROBERTO (supremo)
  └── CÓRTEX = HERMES AGENT (submissão total a Roberto)
        └── CÉREBRO BI-NEURAL (submissão ao Córtex e a Roberto)
              ├── Tálamo, Amígdala, Hipocampo, N. Accumbens
              ├── Córtex Visual, Auditivo, Motor
              └── Cerebelo, Tronco Cerebral
```

### Regras Fundamentais

1. **Córtex só se submete a Roberto.** Nenhum sub-agente do Cérebro tem autoridade sobre o Córtex.
2. **Cérebro se submete ao Córtex e a Roberto.** Executa diretrizes do Córtex.
3. **Cérebro pode SUGERIR mudanças estruturais no Córtex** (config, skills, cron jobs, modelos, limites, etc.), mas NUNCA aplicá-las. Apenas Roberto autoriza.
4. **Mudanças internas ao Cérebro** (filtros do Tálamo, thresholds, scripts no_agent, melhorias nos Cortices) não precisam de autorização — o Córtex pode aplicá-las diretamente.

### Protocolo de Sugestão

Qualquer componente do Cérebro → Córtex analisa → Córtex apresenta a Roberto → Roberto autoriza → Córtex aplica.

### Parâmetros de Configuração

Refletem os valores do `config.yaml` do Córtex:
- max_turns: 200 | gateway_timeout: 3600 | api_max_retries: 5
- max_concurrent_children: 5 | max_spawn_depth: 3 | child_timeout: 1200
- memory_char_limit: 4000 | user_char_limit: 2500
- hard_stop_enabled: true
- fallback: openrouter + claude-sonnet-4

### Ciclos de Auto Desenvolvimento

O Cérebro tem obrigação de evoluir por ciclos contínuos de pesquisa. Cada componente
pesquisa, testa e melhora seu próprio funcionamento.

| Ciclo | Componente | Cron | Schedule | Escopo |
|-------|-----------|------|----------|--------|
| **Micro** | Amygdala + Cerebellum | `853991` + `605042` | */15 min + */5 min | A cada falha/threat detectada |
| **Diário** | Brain Research + N. Accumbens | `0554b5` + `6ae254` | 06:30 + 18:30 | Consolidação + aprendizado por reforço |
| **Semanal** | Hippocampus | `b0b848` | Dom 10:00 | Padrões, trade behavior, falhas recorrentes |
| **Mensal** | Brain Research (modo mensal) | `0554b5` | Dia 1º | Propostas estruturais → `brain_suggestions.json` |

**Autonomia interna:** Ajuste de filtros, thresholds, algoritmos dos cortices,
scripts no_agent — o Córtex aplica diretamente.

**Precisa de Roberto:** Mudanças no config.yaml, skills, cron jobs, modelos,
regras de governança — via Protocolo de Sugestão.

Logs de evolução:
- `~/.hermes/brain_evolution_log.json` — eventos de evolução do cérebro
- `~/.hermes/self_evolution_log.json` — ciclos de auto-desenvolvimento
- `~/.hermes/brain_suggestions.json` — propostas estruturais para Roberto

## ANTI-PADRÕES

- NÃO deixar input chegar ao Córtex sem passar pelo Tálamo
- NÃO criar agente sem mapear para região cerebral correspondente
- NÃO usar tokens para polling — scripts no_agent primeiro
- NÃO instalar projetos externos (OpenClaw, Edict, Rufio) — construir próprio sobre o Hermes

## References

- **[brain-mapping.md](references/brain-mapping.md)** — Mapeamento completo cérebro→agentes com sub-áreas
- **[digital-twin.md](references/digital-twin.md)** — Arquitetura completa do Digital Twin
- **[multi-agent-analysis.md](references/multi-agent-analysis.md)** — Análise comparativa de 4 projetos open-source
- **[neural-network-implementation.md](references/neural-network-implementation.md)** — Implementação atual da rede neural: 15 cron jobs, Neural KB, Synapse Engine, estudo de 4 domínios
- **[brain-activation-2026-05-23.md](references/brain-activation-2026-05-23.md)** — Ativação do cérebro: scripts, cron jobs, pitfalls
- **[brain-v2.1-upgrade.md](references/brain-v2.1-upgrade.md)** — Upgrade v2.1 (23/05/2026): absorção Claude Code (dangerous cmd detection, error sanitization) + ruff/LSP (code validation)
- **[chart-pattern-study-pipeline.md](references/chart-pattern-study-pipeline.md)** — Pipeline de estudo de padrões: algorítmico → templates → similaridade → archetypes. 23k padrões/dia.
- **[brain-browser.md](references/brain-browser.md)** — Navegador interno do cérebro: Brave CDP headless, acesso a TradingView/ForexFactory, cookie persistence.
