---
name: bi-neural-brain
description: "Arquitetura do cérebro bi-neural da ENTIDADE — sistema multi-agente inspirado no cérebro humano com Tálamo (router), Cortices especializados (Visual, Audio, Motor), e Córtex Pré-Frontal (Hermes Agent como núcleo decisor)."
version: 1.0.0
author: Roberto Rodrigues
license: MIT
metadata:
  hermes:
    tags: [brain, multi-agent, architecture, thalamus, cortex, bi-neural]
    related_skills: [life-os, architecture, financial-intelligence, system-health]
---

# 🧠 Cérebro Bi-Neural — Arquitetura Multi-Agente

Sistema nervoso artificial da ENTIDADE. Inspirado no cérebro humano, implementado como agentes Python puros, zero dependências externas.

## ARQUITETURA (v2.0 — 23/05/2026)

```
DISPOSITIVOS (input)
    │
    ▼
SENSOR AGENTS (coleta: email, telegram, forex, sistema, pesquisa web)
    │
    ▼
TÁLAMO (router central — classifica, prioriza, decide se acorda o Córtex)
    │
    ├── AMÍGDALA  ├── HIPOCAMPO  ├── N. ACCUMBENS  ├── CEREBELO
    │   (urgência)    (memória)     (aprendizado)     (validação)
    │
    ▼
CÓRTEX PRÉ-FRONTAL (Hermes Agent = ENTIDADE)
    │
    ▼
CORTICES ESPECIALIZADOS
    ├── Visual Cortex    (👁️ ver, OCR, detectar elementos)
    ├── Audio Cortex     (👂 ouvir, transcrever)
    └── Motor Cortex     (🦾 agir, clicar, digitar, executar)
    
    ═══════════════════════════════════════
    
REDE NEURAL (Synapse Engine + Neural KB)
    │  conhecimento compartilhado entre TODOS os módulos
    │
    ├── FOREX RESEARCH PIPELINE
    │   ├── Research Collector  (YouTube+RSS+Web, diário 03:00)
    │   ├── Chart Pattern Study (CHoCH/FVG/OB/BOS, seg-sex 08:00)
    │   └── Weekly Analyzer     (LLM insights, Dom 11:00)
    │
    ▼
EXECUTIVE MODULE v2 (State Machine + Stall Detection)
    │
    ▼
BRAIN RESEARCH (Ciclo de auto-desenvolvimento, diário 06:30)
```

## MÓDULOS IMPLEMENTADOS

### Tálamo (`~/.hermes/thalamus/`)
Message router central. TODO input passa por aqui antes de chegar ao Córtex.

- **router.py** — Core: `Thalamus` class + `route()` — classifica e decide se acorda
- **schema.py** — Formato canônico `Event` + enums (`EventType`, `Urgency`, `Source`)
- **filters.py** — Pipeline de 8 filtros com keyword scoring

**API:**
```python
from thalamus.router import Thalamus
t = Thalamus()
event = t.route("email", "Problema no saque", metadata={"from": "cliente@x.com"})
# event.type → FINANCE | SOCIAL | SYSTEM | CORTEX | SPAM
# event.urgency → L1(normal) | L2(atenção) | L3(urgente)
# event.should_wake → True se precisa acordar o Córtex
```

**Regras de filtro (ordem de prioridade):**
1. Spam → descartado
2. **Error sanitization** (v2.1) → detecta injection via tool errors → descartado
3. Trade executado → FINANCE L3 → acordar
4. Erro crítico → SYSTEM L3 → acordar
5. Email de cliente → SOCIAL L2 → acordar
6. Warning sistema → SYSTEM L2 → acordar
7. Alerta forex → FINANCE L1/L2
8. Health check OK → SYSTEM L1 → ignorar
9. Newsletter → SOCIAL L1 → ignorar

### Visual Cortex (`~/.hermes/cortex/visual.py`)
Visão computacional do desktop. Vê e controla qualquer software.

- Screenshot: Xvfb (Wine/MT5), D-Bus portal (Wayland), mss (fallback)
- OCR: Tesseract (eng+por) — lê texto de qualquer tela
- Element detection: OpenCV template matching + OCR bounding boxes
- Window management: xdotool (listar, focar, mover)
- Mouse/keyboard: xdotool (clicar, digitar, atalhos)

### Audio Cortex (`~/.hermes/cortex/audio.py`)
Processamento de áudio.

- Microphone capture: PyAudio ou arecord (fallback)
- Speech-to-text: faster-whisper (local, modelo tiny/base)
- Audio analysis: nível de som, detecção de silêncio

### Motor Cortex (`~/.hermes/cortex/motor.py`)
Execução de ações — mouse, teclado, trades.

- Mouse: mover, clicar, duplo clique, arrastar, botão direito
- Keyboard: teclas, combinações, digitar texto
- MT5: F9 → ordem completa (símbolo, volume, SL, TP, Buy/Sell)
- Apps: atalhos predefinidos para MT5, WhatsApp e outros

## FLUXO DE PROCESSAMENTO

Todo evento segue o pipeline:
```
Sensor → Tálamo (classifica) → Amígdala (urgência?) → Córtex (decide) → Motor (executa) → Cerebelo (valida)
```

## PADRÕES DE DESENVOLVIMENTO

### Regra #1: Zero dependências externas
Cada módulo usa apenas Python stdlib + bibliotecas já instaladas no sistema.
Não instalar frameworks nem projetos externos (OpenClaw, Edict, Rufio).
Estudar código alheio para aprender padrões, mas implementar próprio.

### Regra #2: Autonomia total local
O sistema deve funcionar 100% offline para processamento.
APIs externas apenas para dados que não existem localmente (Yahoo Finance, email, Telegram).

### Regra #3: Tálamo como porta única
NENHUM input chega ao Córtex sem passar pelo Tálamo.
Se um novo sensor é adicionado, ele publica eventos no Tálamo.
O Tálamo não sabe o que é um smartwatch ou um óculos VR — só sabe que há eventos chegando.

## ESTUDO DE REFERÊNCIA (19-21/05/2026)

Analisamos 4 projetos open-source para extrair padrões:

| Projeto | Melhor feature | Aplicável? |
|---------|---------------|------------|
| Hermes Agent | Delegate tree + toolset narrowing | ✅ Já temos |
| OpenClaw | Push-based completion + steering | 📋 Plano |
| Edict | State machine + event bus + stall detection | 📋 Plano |
| Rufio | 3-tier routing + swarm topologies + consensus | 📋 Plano |

**Decisão:** Não instalar nenhum. Construir o nosso com os padrões aprendidos.

> ⚠️ **SOBREPOSIÇÃO:** Esta skill tem overlap significativo com `brain-architecture` — ambas descrevem o cérebro bi-neural. `brain-architecture` é a skill primária (autoridade: `~/.hermes/brain_governance.md`). Consulte `brain-architecture → references/neural-network-implementation.md` para o estado atual completo (15 cron jobs, Neural KB, Synapse Engine).

## COMPONENTES DO CÉREBRO (Status 23/05/2026)

### Núcleo Cognitivo

| # | Componente | Script | Cron | Schedule | Status |
|---|-----------|--------|------|----------|--------|
| 1 | **Amígdala** — threat detector | `scripts/amygdala.py` | `853991` | */15 min | ✅ |
| 2 | **Hipocampo** — pattern consolidator | `scripts/hippocampus.py` | `b0b848` | Dom 10:00 | ✅ |
| 3 | **N. Accumbens** — reinforcement learner | `scripts/n_accumbens.py` | `6ae254` | 18:30 seg-sex | ✅ |
| 4 | **Cerebelo v2.1** — action validator + dangerous cmd detector | `scripts/cerebellum.py` | `605042` | */5 min seg-sex | ✅ |
| 5 | **Brain Research** — auto-dev cycle | `scripts/brain_research.py` | `0554b5` | 06:30 diário | ✅ |
| 6 | **Executive v2** — state machine + stalls | `executive/brain.py` | `fcdf34` | */5 min seg-sex | ✅ |
| 7 | **Brain Code Validator** (AP-12) — LSP-style validation | `scripts/brain_code_validator.py` | — | sob demanda | ✅ |

### Pipeline de Pesquisa Forex

| # | Componente | Script | Cron | Schedule | Tokens |
|---|-----------|--------|------|----------|--------|
| 7 | **Research Collector** — RSS+YouTube+Web | `scripts/forex_research_collector.py` | `7b5698` | 03:00 diário | zero |
| 8 | **Chart Pattern Study** — padrões ICT (algorítmico) | `scripts/chart_pattern_study.py` | `005295` | 08:00 seg-sex | zero |
| 9 | **Chart Degraded Study** — pattern templates + similarity | `scripts/chart_pattern_degraded.py` | `131329` | 08:30 seg-sex | zero |
| 10 | **Chart Visual Learner** — screenshots MT5 + OCR | `scripts/chart_visual_learner.py` | — | sob demanda (MT5) | zero |
| 11 | **Weekly Analyzer** — LLM insights | (prompt direto) | `89158e` | Dom 11:00 | ~500/sem |

### Rede Neural (Cross-Module Learning)

| # | Componente | Script | Cron | Schedule | Tokens |
|---|-----------|--------|------|----------|--------|
| 10 | **Neural KB** — conhecimento compartilhado | `scripts/neural_kb.py` | — | sob demanda | zero |
| 11 | **Synapse Engine** — cruzamento neural | `scripts/synapse_engine.py` | `5e4e46` | 07:00 diário | zero |
| — | **KB Bridge** — helper integração | `scripts/kb_bridge.py` | — | importado pelos módulos | zero |
| — | **Córtex Sync** — ponte Córtex↔KB | `scripts/cortex_sync.py` | — | session startup/end | zero |

### Estudo de Sistema (System & Self)

| # | Componente | Script | Cron | Schedule | Tokens |
|---|-----------|--------|------|----------|--------|
| 12 | **System Study Collector** — SO+agentes+arch+córtex | `scripts/system_study_collector.py` | `7d50bd` | Sáb 03:00 | zero |
| 13 | **System Study Analyzer** — LLM insights | (prompt direto) | `7074dc` | Sáb 12:00 | ~500/sem |

**Total: 16 cron jobs + 1 sob demanda — 14 no_agent (zero tokens) + 2 LLM semanais**

### Pendente
- Integração com dispositivos externos (smartphone, smartwatch, VR)
- Video IDs do ICT Concepts para o Research Collector (`~/.hermes/forex/research_sources.json`)
- Migração do /home para LVM (`mkfs` bloqueado pelo agente — requer ação manual)
- **Chart Visual Learner** ativar quando MT5 reconectar no Xvfb :99

## CÓRTEX NA REDE NEURAL

O Córtex (Hermes Agent) é parte ativa da rede neural. Usa `scripts/cortex_sync.py`:

```bash
python3 scripts/cortex_sync.py --summary   # 1 linha: sinapses, regime, pares ativos
python3 scripts/cortex_sync.py --write "insight" --category "modulo"
```

Categories válidas: brain_research, n_accumbens, chart_patterns, amygdala, cerebellum, hippocampus.

Session-startup inclui leitura da rede neural no passo 5.

## REDE NEURAL — CONHECIMENTO COMPARTILHADO

Camada que permite que TODOS os módulos absorvam conhecimento uns dos outros.

### Neural Knowledge Base (`~/.hermes/neural_knowledge_base.json`)
Base JSON com estado global, dados de cada módulo, sinapses e evolução.
Módulos escrevem via `kb_bridge.write()` e leem via `kb_bridge.read()`.

### Synapse Engine (`scripts/synapse_engine.py`)
Diário 07:00. Coleta outputs de todos os módulos, detecta correlações
(ex: qualidade CHoCH → WR do par), cria sinapses, detecta market regime.

### KB Bridge (`scripts/kb_bridge.py`)
```python
from kb_bridge import write, read, global_state, synapse, query
write('amygdala', {'threat_level': 'elevated'})
regime = query('market_regime')
synapse('chart_patterns', 'n_accumbens', 'EURUSD: setups despite PAUSE', 0.8)
```

### Módulos Integrados (leitura+escrita bidirecional)
- **Amygdala**: escreve threats + verifica cerebellum health
- **N. Accumbens**: escreve weights + lê market regime para recomendações
- **Chart Patterns**: escreve padrões + detecta divergências com N. Accumbens
- **Cerebellum**: escreve module health sempre (mesmo sem falhas)

## GOVERNAÇÃO E HIERARQUIA

Documento completo: `~/.hermes/brain_governance.md`

### Cadeia de Comando

```
ROBERTO (autoridade suprema)
  │
  └── CÓRTEX PRÉ-FRONTAL (Hermes Agent)
      submissão total e imutável a Roberto
      │
      └── CÉREBRO BI-NEURAL (todos os sub-agentes)
          submissão ao Córtex e a Roberto
```

### Regras

- **Córtex obedece APENAS a Roberto.** Nenhum componente do Cérebro tem autoridade sobre o Córtex.
- **Cérebro obedece ao Córtex e a Roberto.** Executa diretrizes do Córtex sem questionamento.
- **Cérebro pode SUGERIR mudanças estruturais no Córtex** (config, skills, cron, modelos, parâmetros), mas NUNCA aplicá-las. O Córtex apresenta a sugestão a Roberto e só ele autoriza.
- **Mudanças internas do Cérebro** (filtros, thresholds, scripts no_agent, cortices) são autonomia do Córtex — não precisam de autorização.
- **Parâmetros do Cérebro espelham o config.yaml do Córtex** — mesmos limites de execução, delegação, memória e guardrails.

### Ciclos de Auto Desenvolvimento

Cada componente do Cérebro mantém ciclos de pesquisa e evolução:
- **Micro:** A cada falha detectada — o componente afetado pesquisa melhoria
- **Diário:** Hipocampo consolida memória do dia
- **Semanal:** Tálamo + Amígdala revisam thresholds e filtros
- **Mensal:** Córtex coordena análise de tendências e propostas estruturais

Autonomia interna: filtros, thresholds, algoritmos dos cortices, scripts no_agent.
Mudanças estruturais: somente via Protocolo de Sugestão → Roberto autoriza.

Log: `~/.hermes/brain_evolution_log.json`

## References

- **[brain-mapping.md](references/brain-mapping.md)** — Mapeamento completo cérebro → agentes
- **[digital-twin.md](references/digital-twin.md)** — Arquitetura de expansão para dispositivos
- **[multi-agent-analysis.md](references/multi-agent-analysis.md)** — Análise dos 4 projetos estudados
- **[ubuntu-hardware-control.md](references/ubuntu-hardware-control.md)** — Diagnóstico e controle do Ubuntu
- **[brain-dev-journal.md](references/brain-dev-journal.md)** — Diário de desenvolvimento
- **[neural-network-layer.md](references/neural-network-layer.md)** — Implementação da Rede Neural (Synapse Engine + KB)

> **Nota:** `brain-architecture` é a skill primária do cérebro. Consulte seus references para:
> - **[chart-pattern-study-pipeline.md](brain-architecture → references/)** — Pipeline de estudo de padrões (23k/dia)
> - **[brain-browser.md](brain-architecture → references/)** — Navegador CDP interno
> - **[brain-v2.1-upgrade.md](brain-architecture → references/)** — Absorção Claude Code + ruff/LSP
