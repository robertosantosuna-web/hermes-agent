# 🧠 Cérebro → Agentes — Mapeamento Neurocientífico

Mapeamento direto entre regiões do cérebro humano e subsistemas da ENTIDADE.

## SISTEMA SENSORIAL (INPUT)

### 👁️ Córtex Visual (Occipital)
- **chart-vision**: Detecta padrões em gráficos forex (CHoCH, FVG, CRT)
- **screen-ocr**: Extrai texto de imagens (tesseract)
- **browser-eye**: Navega e lê DOM (browser CDP)
- **whatsapp-reader**: Lê conversas do WhatsApp Web

### 👂 Córtex Auditivo (Temporal)  
- **audio-transcriber**: Converte áudio em texto (faster-whisper)
- **voice-parser**: Extrai intenção de áudio transcrito

### 🖐️ Córtex Somatossensorial (Parietal)
- **system-health**: CPU, RAM, disco, temperatura
- **market-pulse**: Preço real-time, spread, volatilidade
- **self-monitor**: Status dos próprios agentes

## SISTEMA DE RETRANSMISSÃO

### 🔄 Tálamo
- **message-router**: Filtra e roteia TODO input
- NADA chega ao Córtex sem passar pelo Tálamo

### ⚡ Formação Reticular
- **alert-system**: Só acorda o sistema com urgência real

## SISTEMA LÍMBICO

### 🐴 Hipocampo → memory-consolidator
### 🐍 Amígdala → threat-detector / priority-classifier
### 🎯 Núcleo Accumbens → reinforcement-learner

## GÂNGLIOS DA BASE

### 🔁 Corpo Estriado → skill-habits / cron-automator

## CÓRTEX PRÉ-FRONTAL (EXECUTIVO = ENTIDADE)

### 🧩 Dorsolateral PFC → Planejamento, working memory
### ⚖️ Orbitofrontal PFC → Decisão, risco/recompensa
### 🔍 Cíngulo Anterior → Detecção de erro, conflito

## SISTEMA MOTOR (OUTPUT)

### 🦾 Córtex Motor → mt5-executor, telegram-sender, browser-clicker
### 🎪 Cerebelo → Coordenação, timing, retry
### 🌱 Tronco Cerebral → Cron jobs essenciais (nunca param)
