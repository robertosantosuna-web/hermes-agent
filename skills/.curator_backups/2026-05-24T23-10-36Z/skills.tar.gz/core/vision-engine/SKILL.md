---
name: vision-engine
description: "Motor local de processamento de imagens — captura Xvfb/Wayland, OCR Tesseract, extração de dados. Backends: Xvfb (MT5/Wine), grim (wlroots), browser (CDP)."
---

# Vision Engine — Motor Local de Imagens
# Vision Engine — Motor Local de Imagens

## Backends

| Backend | Comando | Uso |
|---------|---------|-----|
| Xvfb | `DISPLAY=:99 import -window root` | MT5, Wine, apps X11 |
| Edge CDP | `Page.captureScreenshot` via WebSocket | Páginas web autenticadas |
| Wayland | `grim` | Sway/wlroots (GNOME não suporta) |
| Browser | `browser_vision` | Conteúdo web (Brave) |

## Comandos

```bash
vision_engine.py xvfb                  # Captura + OCR Xvfb (MT5)
vision_engine.py xvfb --numbers-only   # Só números (preços)
vision_engine.py ocr_only --image /path/img.png --lang por  # OCR imagem
vision_engine.py mt5_account           # Conta MT5 (região inferior)
```

## Edge CDP — extração de dados visuais de páginas autenticadas

Quando `browser_vision` (Brave) não está logado mas o Edge CDP (:9222) tem sessão ativa:

```python
# 1. Abrir aba no domínio autenticado
urllib.request.urlopen(urllib.request.Request(
    'http://localhost:9222/json/new?https://site.com', method='PUT'))

# 2. Capturar screenshot da página
ws = websocket.create_connection(f'ws://localhost:9222/devtools/page/{page_id}')
ws.send(json.dumps({"id":1, "method":"Page.captureScreenshot", "params":{"format":"png"}}))
# Decodificar base64 → salvar PNG → OCR

# 3. Extrair texto direto do DOM
ws.send(json.dumps({"id":2, "method":"Runtime.evaluate",
    "params":{"expression": "document.body.innerText", "returnByValue": True}}))
```

**Páginas com sessão ativa no Edge CDP (:9222):** Gmail, 99Freelas, OANDA, TradingView, Toloka.

## PITFALLS

- **DeepSeek não suporta visão nativa**: `vision_analyze` retorna `unknown variant image_url`. Usar OCR (vision_engine) como fallback para ler imagens.
- **GNOME Wayland**: grim retorna `wlr-screencopy` error. Usar Xvfb ou Edge CDP.
- **PEP 668**: script usa `#!/usr/bin/python3` (system python).
- **Xvfb sem WM**: `windowactivate` falha → usar `windowfocus` + teclas diretas.
- **OCR do MT5 não lê números**: saída típica "2- - +". Para dados financeiros, usar xdotool Ctrl+C ou F9+Tab.
- **OCR de tabelas MT5**: qualidade baixa para dados estruturados. Preferir `xdotool` Ctrl+C sobre o OCR.

## CDP Screenshot (Edge autenticado)

Para páginas com sessão ativa no Edge (:9222), usar Page.captureScreenshot via WebSocket CDP.
Ver `freelancing-automation` → `references/edge-cdp-conversation-extraction.md`.
- **OCR não lê números financeiros**: 95% confiança mas saída típica do MT5 é `"2- - +"`. O pré-processamento (grayscale+contraste+threshold) melhora menus mas não resolve para tabelas de preços/saldo. **Para dados estruturados do MT5, usar xdotool Ctrl+C no Trade Terminal (Ctrl+T → Ctrl+A → Ctrl+C), NÃO OCR.** OCR serve apenas para confirmação visual (ex: "a janela de ordem abriu?").
