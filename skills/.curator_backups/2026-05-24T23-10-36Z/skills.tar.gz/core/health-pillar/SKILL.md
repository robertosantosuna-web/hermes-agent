---
name: health-pillar
description: "Pilar Saúde da ENTIDADE: hábitos, acompanhamento psicológico, metas de bem-estar. Segundo pilar após Financeiro estar rodando de forma autônoma."
version: 1.0.0
---

# Pilar Saúde — Bem-estar Físico e Psicológico

## Status: ATIVO (24/05/2026) — Fase Foundation (Semanas 1-2)

Ativado por override do Roberto. Modo Tiny Habits: 3 âncoras microscópicas.
Base de conhecimento completa: 9 frameworks, 5 autores.
Tracking ativo com check-ins 07:00 e 21:00 via cron.

## O que sabemos do Roberto (mapeamento 14/05)

- 32 anos, 1.80m (estimado)
- Recuperando de depressão desde a época do casamento
- Sentimento de estagnação pós-divórcio
- Mora com pai e irmã — sente-se sufocado
- Baixa autoestima ligada a situação financeira
- Quer: academia, comer bem, vestir-se bem, ter confiança

## Base de Conhecimento Compilada (Maio/2026)

> Ver arquivo completo: `~/.hermes/mental/pillar_knowledge.md`
> Arquivos-fonte detalhados: `~/frameworks_research.md`, `~/mental_change_protocols.md`, `~/self-influence-protocols.md`

### Arquitetura do Pilar

```
NEUROPLASTICIDADE (hardware)   HÁBITOS (behavior)   COGNIÇÃO (software)
Doidge + Davidson + Flow      Fogg + Clear + Duhigg   Beck (TCC) + Ellis (REBT)
         │                          │                        │
         └──────────────────────────┼────────────────────────┘
                                    ▼
                         SISTEMA DE INFLUÊNCIA
                         Cialdini + Militares
```

### 9 Frameworks Armazenados

| Camada | Framework | Autor | Princípio Central |
|--------|-----------|-------|-------------------|
| Neuro | Plasticidade Neural | Norman Doidge | Neurônios que disparam juntos conectam-se — atenção é o gatekeeper |
| Neuro | 6 Estilos Emocionais | Richard Davidson | Cada estilo tem base neural treinável |
| Neuro | Flow State | Csikszentmihalyi | Flow desliga DMN (rede de ruminação) — antidepressivo natural |
| Hábitos | Behavior Design (B=MAP) | BJ Fogg | Behavior = Motivation + Ability + Prompt |
| Hábitos | Tiny Habits (ABC) | BJ Fogg | Anchor → Behavior minúsculo → Celebration (dopamina) |
| Hábitos | Atomic Habits (4 Leis) | James Clear | Óbvio, Atraente, Fácil, Satisfatório — identity-based |
| Hábitos | Loop do Hábito | Charles Duhigg | Cue → Routine → Reward + Craving |
| Cognição | TCC — Distorções Cognitivas | Aaron Beck | Não é o evento, é a interpretação — 11 distorções mapeadas |
| Cognição | REBT — ABCDEF | Albert Ellis | 3 Musts irracionais → disputar → preferências racionais |
| Influência | 6 Princípios | Robert Cialdini | Reciprocidade, Compromisso, Prova Social, Autoridade, Afeição, Escassez |
| Influência | Disciplina Militar | Marines/SEALs | 3-2-1-Go, 40% Rule, General Orders, Embrace the Suck |

### Protocolo Diário Pronto (quando ativar)

- **Manhã (~25 min):** 3 respirações + 3 Good Things + thought check + intenção
- **Dia:** 90-segundo rule p/ emoções + trigger cards + micro-flow 20 min
- **Noite (~20 min):** thought record ou vitória + habit tracker + celebrate + preparar ambiente
- **Semanal:** Seg=Thought Record, Qua=Shame Attack, Sex=Flow Challenge, Dom=Review

### Anti-Padrões

- ❌ NÃO ativar tracking antes do financeiro
- ❌ NÃO começar com metas grandes (Tiny Habits first)
- ❌ NÃO pular Celebration (Fogg: é o passo mais importante)
- ❌ NÃO depender de motivação (Fogg: least reliable lever)
- ❌ NÃO substituir terapia profissional — é complemento

## Integração Futura (Digital Twin)

Quando o ecossistema evoluir para integração total:
- Dados do smartphone (passos, atividade, localização)
- Smartwatch (batimentos, sono, estresse)
- VR (imersão, terapia, treinamento)
- Monitoramento de vícios e hábitos
- Intervenções proativas (sugerir pausa, exercício, água)

## Anti-Padrões

- NÃO ativar este pilar antes do financeiro
- NÃO dar conselhos médicos/psicológicos não solicitados
- NÃO monitorar sem consentimento
- NÃO julgar escolhas do Roberto
