---
name: 99freelas-automation
description: "Automação do 99Freelas via Desktop Daemon + ydotool. Contorna Cloudflare Turnstile e React controlled components usando input kernel-level."
version: 1.0.0
---

# 99Freelas Automation — Pipeline Validado

## Regra de Ouro

**NUNCA use CDP para INPUT no 99Freelas.** O site usa React com componentes controlados que rejeitam toda manipulação programática de `value`. Input só funciona via teclado kernel-level (ydotool).

**CDP é SÓ para LEITURA:** DOM, coordenadas, anexar arquivos, verificar estado.

## Pipeline

```
CDP (porta 9222, Brave Wayland)
  • Ler DOM, mensagens, coordenadas
  • Anexar arquivos (DOM.setFileInputFiles)
  • Verificar estado da página
  • NUNCA digitar texto, NUNCA clicar em botões
         │ coordenadas
         ▼
Desktop Daemon (porta 9876, ydotool)
  • Clicar em posições exatas da tela
  • Digitar texto (kernel-level, React reconhece)
  • Pressionar teclas (Enter, Tab)
```

## Coordenadas

Tela 1920x1080 (monitor único donde Brave está). Brave Wayland na porta 9222.

**Obter coordenadas absolutas:**
```js
const rect = element.getBoundingClientRect();
const absX = Math.round(rect.left + window.screenX + rect.width/2);
const absY = Math.round(rect.top + window.screenY + rect.height/2);
```

⚠️ `mss` no daemon reporta 3840 (dois monitores), mas o navegador está em 1920.

## Digitação ABNT2-safe

ydotool com ABNT2 corrompe: `ç ã é í ó ú ê ô à õ / :`

**Solução:** Mensagens em ASCII puro. Substituir acentos por equivalentes sem acento.

## Anexar Arquivos

```python
# 1. Daemon: clicar "Anexar Arquivo(s)"
# 2. CDP DOM.setFileInputFiles no input[type="file"]
# 3. CDP: dispatchEvent(new Event('change', {bubbles: true}))
# 4. Arquivo é enviado junto com a próxima mensagem
```

## Verificação

Após cada ação, verificar via CDP `document.body.innerText`.

## Pitfalls

1. ❌ `Input.insertText` → React ignora
2. ❌ `Input.dispatchKeyEvent` → React não reconhece
3. ❌ `textarea.value = "..."` → React tem estado interno
4. ❌ `navigator.clipboard.writeText` → requer user gesture
5. ✅ Só ydotool (kernel-level) convence React
6. ⚠️ Enter via ydotool key nem sempre funciona → preferir clique no botão
7. ⚠️ Ctrl via ydotool pode ficar preso → evitar combos

## Fluxo Típico

```python
# 1. CDP: verificar estado e pegar coordenadas
coords = cdp_eval('getBoundingClientRect + window.screenX/Y')

# 2. Daemon: clicar no textarea
daemon.click(tax, tay)

# 3. Daemon: digitar (ASCII puro)
daemon.type("Mensagem sem acentos")

# 4. Daemon: clicar Enviar
daemon.click(btnx, btny)

# 5. CDP: verificar
assert 'minha mensagem' in cdp_eval('document.body.innerText')
```
