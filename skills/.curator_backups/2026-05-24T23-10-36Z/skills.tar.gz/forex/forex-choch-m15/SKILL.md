---
name: forex-choch-m15
description: "V4 FVG ICT M15 + ICT Avançado (Breaker/Turtle/Mitigation) + Order Flow (Delta/CVD) + Wyckoff (Effort vs Result). 5059 padrões, gap≥5 + horas[6,7,15,16], USDJPY #1 (73.3%). TradingView fonte primária. ~135 fontes de pesquisa avançadas."
---

# Forex CHoCH+FVG @ M15 — Validada

## Resultado do backtest — SEM RESTRIÇÕES (21/05/2026)

**Backtest com S/R Levels (21/05):** CRT + S/R = melhor assertividade.

| Estratégia | Trades | WR | PnL |
|-----------|--------|-----|------|
| CRT baseline | 186 | 68.8% | +1,032p |
| **CRT + S/R** | **113** | **72.6%** | **+733p** |
| CRT + H1 + S/R | 22 | 72.7% | +138p |

Filtro S/R: entrada a ≤5 pips de swing high/low anterior. Sobe WR +3.8pp.

**Bot atual:** CRT + S/R Levels ativos no demo. `SR_ENABLED=True`, `SR_PROXIMITY_PIPS=5`.

## Regras (V4 — 23/05/2026)

- **Estrategia:** FVG ICT (Fair Value Gap, 3 velas)
- **Timeframe:** M15
- **Pares:** USDJPY (primário), GBPUSD (secundário), EURUSD (terciário)
- **RR:** 3:1
- **Horários:** UTC [6, 7, 15, 16] — London open + NY afternoon
- **FVG mínimo:** 5 pips (gap ≥ 5)
- **SL:** max(FVG width, 5 pips)
- **TP:** SL × 3
- **Timeout:** 3 candles sem tocar o FVG → sair
- **Dedup:** 1 trade por par+direção por dia
- **MAX_POSITIONS:** 4 (reduzido de 8 — setups são raros com filtros)
- **CHoCH:** NÃO usar como entrada M15 standalone (7 sinais em 60 pair-dias)
- **BOS:** NUNCA usar como entrada (0-12% WR em 328 padrões)
- **CRT:** candle > 80% percentil + confirmação (2ª vela fecha dentro do range) — mantido como filtro adicional

## O que NAO funciona (atualizado 23/05)

| Sinal | M15 WR | Status |
|-------|--------|--------|
| BOS (Break of Structure) | 0-12% | ❌ Fim do movimento, nunca entrada |
| CHoCH standalone M15 | ~0-50% (7 sinais) | ❌ Raro demais, sem significância |
| FVG sem filtro de gap | 48.3% | ❌ Coin flip |
| FVG evening (18-23 UTC) | 37% | ❌ Sem volume institucional |
| FVG Asian (0-5 UTC) | 30-40% | ❌ Sem volume |
| AUDUSD FVG | 45.7% | ❌ Par não forma FVGs confiáveis |
| NZDUSD FVG | 44.3% | ❌ Par não forma FVGs confiáveis |
| Doji antes do FVG | 44% | ❌ Indecisão mata o setup |
| Sweep+FVG (programático) | 4% | ❌ Sweep algorítmico não funciona |

## ICT Conceitos Avançados (24/05/2026)

Três padrões ICT que constroem SOBRE o FVG/CHoCH. Aprendidos via auditoria de ~135 fontes.

### Breaker Block (Failed OB Reversal)
Order Block que falhou → vira suporte/resistência no reversal. Filtra FVGs perto de OBs já quebrados.
Guia completo: **[references/advanced-ict-concepts.md](references/advanced-ict-concepts.md)**.

### Turtle Soup (False Breakout Fade)
Falso rompimento de swing high/low → aprisiona retail → reverte. Afina com FVG pós-sweep.
Integração direta: detectar Turtle Soup → procurar FVG na direção da reversão.

### Mitigation Block (Liquidity Grab Continuation)
Liquidity grab breve antes da continuação da tendência. Diferencia reversal real de armadilha.

**Prioridade de estudo:** Turtle Soup → Breaker Blocks → Mitigation Blocks.
**Fontes:** innercircletrader.net (PDFs gratuitos), FXNX, ATAS.

## Order Flow — Previsão de Direção (24/05/2026)

Técnicas para prever direção além do price action puro. Guia completo: **[references/order-flow-direction-prediction.md](references/order-flow-direction-prediction.md)**.

### Delta Divergence (sinal mais acionável)
Preço faz higher high, delta faz lower high → exaustão compradora, reversão iminente.
Fontes: ATAS (atas.net), ForexBee (forexbee.co).

### CVD (Cumulative Volume Delta)
Running total de delta. CVD flat + preço subindo = sem suporte institucional.
Fonte: Bookmap (bookmap.com).

### Absorption
Volume alto sem avanço de preço = instituições absorvendo. Próximo candle reverte.
Detecção sem order flow: candle com sombra longa + volume relativo alto.
Fonte: Trader Dale (trader-dale.com).

⚠️ Yahoo Finance NÃO tem volume forex. MT5 fornece tick volume (proxy ~70-80% correlacionado).

## Wyckoff — Esforço vs Resultado (24/05/2026)

Detecta footprints institucionais usando APENAS price action. Guia: **[references/wyckoff-institutional-footprints.md](references/wyckoff-institutional-footprints.md)**.

**Effort vs Result:** Volume alto + candle pequeno = absorção → próximo candle reverte.
**Spring:** Falso breakdown abaixo do suporte → BUY (idêntico ao Turtle Soup no suporte).
**Upthrust:** Falso breakout acima da resistência → SELL.

Integração M15: FVG com volume BAIXO = skip. FVG com volume ALTO = entrar.

## Bugs Corrigidos (20/05/2026)

1. **☠️ FVG INDEX BUG:** `detect_choch_fvg` usava `df.iloc[j]` com índices do slice `df['High'].values[-30:]` (0-29) no DataFrame completo (388+ velas). FVG era buscado em velas de 5 dias atrás, não nas últimas 30. Fix: `df30 = df.iloc[-30:]` + `df30.iloc[j]`. Sinais agora são detectados corretamente nas últimas 30 velas.

2. **☠️ DEDUP SILENCIOSO:** `except: traded_today=[]` engolia erros de leitura do JSON. Se arquivo corrompido/travado, dedup bypassava e abria trades duplicados. Fix: log do erro + fallback via `real_state.json` + filtro `status != 'duplicate'`.

3. **✅ P&L TRACKING:** Adicionado `check_positions()` — a cada ciclo verifica SL/TP via preço atual (yahoo 5m). Trades fechados atualizam `trade_log.json` com `pnl`/`exit_price`/`result`.

## ⚠️ WR THRESHOLD ENFORCEMENT (22/05/2026 — CORRIGIDO)

**REGRA:** WR<40% → NÃO ABRIR ORDEM. WR≥40% → RR mínimo 3:1. WR≥80% → RR livre.

**🚨 BUG CRÍTICO CORRIGIDO:** O bot usava `cfg['wr']` hardcoded do backtest (~67%) em vez do WR real da conta. Resultado: bot abria ordens mesmo com WR real de 33% e -39.7 pips de loss. Self-learning NUNCA foi implementado — era só intenção no código.

**Solução implementada em `forex_bot_real.py`:**

```python
def get_real_wr(pair=None, min_trades=3):
    """Calcula WR real da conta a partir do trade_log."""
    # Lê trade_log.json, filtra trades fechados com pnl
    # Se pair=None, retorna WR agregado de todos os pares
    # Se < min_trades, retorna None

def should_trade_pair(pair):
    """Decide se deve operar um par."""
    # 1. Par com 3+ trades e WR < 40% → BLOQUEAR
    # 2. Par com 2+ trades e WR ≥ 80% → PERMITIR (exceção elite)
    # 3. Agregado com 10+ trades e WR < 35% → BLOQUEAR pares < 50%
    # 4. Menos de 3 trades → PERMITIR (backtest como referência)
```

**Estado atual (22/05):**
| Par | Real WR | Status |
|-----|---------|--------|
| NZD/USD | 100% (2W/0L) | ✅ Único par liberado |
| GBP/USD | 25% (1W/3L) | ❌ BLOQUEADO |
| AUD/USD | 25% (1W/3L) | ❌ BLOQUEADO |
| EUR/USD | 0% (0W/2L) | ❌ BLOQUEADO |
| Agregado | 33.3% (4W/8L) | -39.7 pips |

**IMPORTANTE:** O campo `PAIRS[].wr` foi renomeado para `PAIRS[].backtest_wr`. NUNCA usar backtest_wr para decisão de trading — é valor de REFERÊNCIA histórica, não reflete performance real.

**Corretoras:**
- OANDA Demo: ⏸️ em standby (#1715539800, Wine+Xvfb :99)
- **IC Markets Demo: ✅ ATIVA (23/05) — MT5 logado no display:0, conta demo hedge (Raw Trading Ltd). Execução via ydotool (não xdotool — MT5 no desktop real, não Xvfb).**
- OANDA Real: ❌ bug na plataforma (senha correta rejeitada)
- Exness: 🟡 cadastro preenchido, depósito $10 pendente (skill `forex-brokers`)

## ⚠️ PITFALL: WR hardcoded (22/05/2026)

O bot usava `cfg['wr']` fixo do backtest (~67%) em vez do WR real da conta. Self-learning nunca existiu — era só intenção.

**Correção**: `get_real_wr(pair)` lê `trade_log.json`. `should_trade_pair(pair)` aplica regras:
- WR real < 40% → BLOQUEAR par
- WR real ≥ 80% (2+ trades) → exceção elite
- Agregado < 35% → bloquear pares com WR < 50%



| TF | CRT Trades | CRT WR | CRT PnL | RAW WR | Veredito |
|----|-----------|--------|---------|--------|----------|
| **M15** | 156 | **74.4%** | +1,263p | 58.5% | ✅ ÓTIMO |
| M30 | 133 | 71.4% | +1,125p | 57.4% | ✅ Bom |
| H1 | 75 | 69.3% | +610p | 59.1% | ⚠️ Poucos trades |
| M5 | 175 | 48.6% | +429p | 45.9% | ❌ Ruído |

**M5 é ruído puro** — CRT não consegue filtrar. **M15 é o sweet spot** com maior WR (74.4%) e volume saudável (~5 trades/dia).

## Sabedoria do Trader

> "Ela tem que aprender a identificar o range e o que é fluxo. Para quando tiver uma quebra de fluxo, identificar como CHoCH, aí procurar FVG para entrada. Se ela não souber identificar estrutura e fluxo, qualquer quebra ela entra."

**Validado pelos vídeos SSC:** O sweep de liquidez antes do CHoCH/FVG é o filtro que separa entrada real de ruído. Implementado no `forex_ssc_full.py`.

## Filtros de Assertividade (backtest 21/05)

Comparação de filtros adicionais sobre baseline CRT (186T, 68.8% WR, +1,032p):

| Filtro | Trades | WR | PnL | Veredito |
|--------|--------|-----|------|----------|
| CRT baseline | 186 | 68.8% | +1,032p | ✅ Base |
| **CRT + S/R Levels** | 113 | **72.6%** | +733p | ✅ **Melhor WR** |
| CRT + H1 + S/R | 22 | 72.7% | +138p | ⚠️ Poucos trades |
| CRT + H1 Trend | 39 | 64.1% | +198p | ❌ Piora WR |
| CRT + Volume | 0 | — | — | ❌ Yahoo sem volume |

**S/R Levels:** Entrada a ≤5 pips de swing high/low anterior. Sobe WR 68.8→72.6%. Script: `~/.hermes/scripts/forex_assertividade.py`.

**⚠️ H1 Trend piora:** Adicionar confirmação H1 REDUZ WR. Estrutura de swings H1 é ruidosa pra filtrar M15. Usar apenas como viés direcional (score), nunca como filtro excludente.

**⚠️ Wyckoff/Sweep inviável:** Pipeline SSC completo (H1→Wyckoff→Sweep→CHoCH→FVG) zera sinais. Sweep programático em M15 não funciona — é análise visual, não algorítmica.

## Filtro CRT Confirmacional

**Origem:** Canal SSC (16 vídeos transcritos, 808 menções). CRT = Candle Range Theory.

**Implementação no bot** (`forex_bot_real.py`):

| Parâmetro | Valor | Descrição |
|-----------|-------|-----------|
| `CRT_ENABLED` | `True` | Ativa/desativa o filtro |
| `CRT_RANGE_PERCENTILE` | `0.8` | Candle precisa ter range > 80% dos últimos 20 |
| Confirmação | 2ª vela fecha dentro do range da 1ª | Evita entrada em vela de exaustão isolada |

**Lógica:**
1. `is_crt_candle(df, idx)`: range do candle atual >= percentil 80 dos últimos 20 candles
2. `crt_confirmation(df, idx)`: o candle seguinte (idx+1) fecha dentro do [Low, High] do candle CRT

**Resultado validado (30d, sem restrições):**
- RAW: 1,315 trades, 51.0% WR, PF 3.1
- CRT: 247 trades, 66.8% WR, PF 17.0
- CRT corta 81% do ruído e triplica o profit factor

## Pares — Ranking V4 (5059 padrões, 5 pares, 30 dias cada)

| Rank | Par | WR Base | WR V4 | Boost | PF V4 | Setups | Veredito |
|------|-----|---------|-------|-------|-------|--------|----------|
| 🥇 | **USDJPY** | 60.7% | **73.3%** | +12.6pp | 8.25 | 16/30d | ✅ PRIORITÁRIO |
| 🥈 | GBPUSD | 53.1% | **65.5%** | +12.4pp | 5.70 | 34/30d | ✅ Primário |
| 🥉 | EURUSD | 48.3% | **56.2%** | +7.9pp | 3.86 | 20/30d | ⚠️ Secundário |
| ❌ | AUDUSD | 45.7% | — | — | — | — | EVITAR |
| ❌ | NZDUSD | 44.3% | — | — | — | — | EVITAR |

**Filtro V4 aplicado:** gap ≥ 5 pips + hora UTC ∈ [6, 7, 15, 16].
**Frequência:** ~2.3 setups/semana (70 em 90 pair-dias).
USDJPY descoberto como melhor par em 23/05 — contradiz análise anterior que descartava USD/JPY para FVG.

**Confirmação independente (24/05):** Segundo backtest com dados frescos do Yahoo Finance confirma ranking idêntico e thresholds. Ver: **[references/backtest-v4-confirmation-2026-05-24.md](references/backtest-v4-confirmation-2026-05-24.md)**.

## Fonte de Dados

**PRIMÁRIA: TradingView** (substituiu Yahoo Finance em 23/05/2026).
Acesso autenticado via Google OAuth no Brave CDP (porta 9223).
Dados OHLCV em tempo real, Pine Script, Bar Replay para backtest visual.
Ver: **[references/tradingview-integration.md](references/tradingview-integration.md)**

**Bot Python** (`forex_bot_real.py`): Yahoo Finance como fallback PROVISÓRIO.
Migração para TradingView concluída para análise visual; execução de trades
ainda usa Yahoo Finance enquanto MT5 está offline.

**EXECUÇÃO: MT5 OANDA demo** — quando conectado. Via xdotool F9 no Xvfb :99.

## ⚠️ ARQUITETURA REAL: PAPER TRADING HÍBRIDO

**Descoberto 22/05/2026:** O "bot real" NUNCA operou dinheiro real. É um sistema híbrido paper/real:

```
forex_bot_real.py  →  yfinance (dados de mercado)
                   →  mt5_direct.py  →  xdotool F9  →  MT5 (Xvfb :99)
                   →  trade_closer.py →  Yahoo Finance (sync P&L)

trade_closer.py    →  fetch_current_price() via Yahoo Finance
                   →  Calcula SL/TP hit com preço do Yahoo (NÃO do MT5)
                   →  Atualiza trade_log.json + real_state.json
```

**O que isso significa:**
- `mt5_direct.py` retorna `{"status": "sent"}` mesmo se o MT5 não estiver rodando ou conectado — ele só envia teclas, não verifica execução
- `trade_closer.py` sincroniza P&L usando preços do Yahoo Finance, não do MT5
- Se o MT5 está offline (0/0Kb), as ordens NUNCA chegam no servidor — mas o sistema registra como se tivessem sido executadas
- Os resultados em `trade_log.json` e `real_state.json` são SIMULADOS, não reais

**Como verificar se o MT5 está REALMENTE conectado:**
```bash
# Método 1: OCR do status bar (canto inferior direito)
xwd -display :99 -root | convert - -crop 500x60+1100+660 /tmp/status.png
convert /tmp/status.png -resize 300% /tmp/status_big.png
tesseract /tmp/status_big.png /tmp/ocr.txt
cat /tmp/ocr.txt
# "0/0Kb" = OFFLINE. "XX/YYKb" com números > 0 = CONECTADO.
```
**Método 2:** Verificar se o título da janela MT5 mostra o nome do servidor após conectar (ex: "OANDA Global Demo-1").

## Execução de Ordens

**Método primário (IC Markets):** `mt5_order_executor.py` — envia ordens no MT5 via ydotool (F9 + Alt+B/S). MT5 roda no desktop real (DISPLAY=:0), não no Xvfb. Exemplo:
```bash
python3 ~/.hermes/scripts/mt5_order_executor.py BUY USDJPY 0.01 --sl 159.00 --tp 159.45
python3 ~/.hermes/scripts/mt5_order_executor.py SELL EURUSD 0.01 --sl 1.1620 --tp 1.1570
```

**Método secundário (OANDA):** `mt5_direct.py` — xdotool F9 no Xvfb :99 (legado, usar apenas se OANDA for reativada).

## Pipeline Dual Agente+Cérebro (23/05/2026)

Fluxo completo de trading com validação cruzada:

```
🧠 CÉREBRO (no_agent, zero tokens)
  brain_signal_generator.py → analisa Yahoo Finance M15
  Escreve → ~/.hermes/forex/signals_pending.json
  
🤖 AGENTE (Hermes, com tokens)
  Lê signals_pending.json → valida no TradingView (browser)
  Confronta com análise própria → decide BUY/SELL/SKIP
  Executa → mt5_order_executor.py (ydotool no MT5 IC Markets)
```

### Scripts do Pipeline

| Script | Função | Quem usa |
|--------|--------|----------|
| `brain_signal_generator.py` | Scanner CHoCH+FVG M15, salva sinais | Cérebro (cron no_agent) |
| `knowledge_bridge.py` | write/read/absorb — conhecimento compartilhado | Ambos |
| `mt5_order_executor.py` | Executa ordens no MT5 via ydotool | Agente |
| `bridge_context.py` | Consulta cruzada agent_context ↔ brain_context | Ambos (leitura) |

### Cron Jobs

| Job ID | Nome | Schedule | Função |
|--------|------|----------|--------|
| 97892173c440 | Brain Weekend Scanner | */2 min (fds) | Scan rápido fim de semana |
| 3ba3d2dc5e8e | Brain Signal Scanner | */15 min (semana) | Scan dias úteis |
| 09e9ee74f193 | Brain Intensive Study | a cada 2h | Estudo completo (coleta+backtest+padrões) |

### Knowledge Bridge

Arquivo compartilhado: `~/.hermes/forex/knowledge_bridge.json`

```bash
# Escrever descoberta
python3 ~/.hermes/scripts/knowledge_bridge.py write agent "Insight..."
python3 ~/.hermes/scripts/knowledge_bridge.py write brain "Insight..."

# Ler descobertas
python3 ~/.hermes/scripts/knowledge_bridge.py read
python3 ~/.hermes/scripts/knowledge_bridge.py read --source brain

# Absorver conhecimento do outro
python3 ~/.hermes/scripts/knowledge_bridge.py absorb agent
python3 ~/.hermes/scripts/knowledge_bridge.py absorb brain
```

### Fluxo de Fim de Semana

Sábado/domingo: mercado fechado → apenas estudo e simulação (TradingView replay).
Brain roda estudo intensivo. Agente descansa. Ambos escrevem descobertas na bridge.
Segunda-feira: ambos analisam independentemente, confrontam, e agente executa no MT5.

### ⚠️ Pitfall: Modelo sem visão

Deepseek não suporta análise de imagem. Agente NÃO consegue ver screenshots de charts.
Alternativas: (1) extrair dados OHLC via Yahoo Finance e analisar algoritmicamente,
(2) usar browser DOM extraction no TradingView, (3) depender da validação cruzada com o cérebro.

## Chart Pattern Study Pipeline (23/05/2026)

O cérebro agora estuda padrões de gráfico visualmente e algaritmicamente:

| Script | Função | Cron | Schedule |
|--------|--------|------|----------|
| `scripts/chart_pattern_study.py` | Detecção algorítmica: CHoCH, FVG, BOS, OB, liquidity levels | `005295` | 08:00 seg-sex |
| `scripts/chart_pattern_degraded.py` | Aprendizado offline: templates numéricos, similaridade cross-pattern, archetypes | `131329` | 08:30 seg-sex |
| `scripts/chart_visual_learner.py` | Visão computacional: screenshots MT5 + OCR + análise de sentimento | — | sob demanda (MT5) |

**Primeiro estudo (23/05):** 23.080 padrões detectados em 5 pares × 3 timeframes.
FVG e BOS são visualmente similares (0.75-0.93). CHoCH é mais raro e seletivo.

### Neural KB Integration
Os scripts escrevem no `kb_bridge` (`chart_patterns`, `visual_cortex`) e criam sinapses com N. Accumbens quando detectam divergências (ex: padrões high-quality vs recomendação PAUSE).

## Integração RUFLo + neural-trader

**neural-trader** instalado em `~/ruflo/node_modules/neural-trader`. Backtest Rust/NAPI (8-19x mais rápido que Python). Comandos:
```bash
cd ~/ruflo && npx neural-trader --backtest <strategy> --symbol EURUSD=X --live --json
```

**Pipeline unificado (em construção):** TradingView (sinal) → Webhook → MT5 (execução) + neural-trader (backtest/risco) + AgentDB (memória).

**Arquitetura completa:** `~/.hermes/forex/arquitetura_unificada.md`

| Job | ID | Script | Schedule | Status |
|-----|-----|--------|----------|--------|
| 🤖 Trading REAL MT5 | 21f7caf29606 | forex_bot_real.py | */15 * * * 1-5 | ⏸️ Pausado (22/05) |
| 📊 Daily Review | c79a771c95a0 | forex_daily_review.py | 0 18 * * * 1-5 | ⏸️ Pausado (22/05) |
| 💰 Trade Closer (P&L) | 5e12477198e4 | trade_closer_close.py | */10 * * * 1-5 | ⏸️ Pausado (22/05) |
| 🩺 MT5 Health Check | 8f3e0f2d4f3e | trade_closer_health.py | */30 * * * 1-5 | ⏸️ Pausado (22/05) |
| 🔒 Fechar Ordens Sexta | de69bd5aa118 | forex_fechar_sexta.sh | 0 16 * * 5 | ✅ Ativo |
| 📊 Golden Hours | 74f1169e6e66 | forex_choch_m15.py | PAUSADO | ⏸️ Pausado |

**Motivo da pausa (22/05):** Bot operava paper trading — MT5 nunca conectou (0/0Kb tráfego). Todas as ordens eram simuladas via Yahoo Finance. Pausado até que o MT5 seja conectado na conta demo OANDA com primeiro login manual.

## Cross-Agent Simulation — 23/05/2026

Hermes e Cérebro rodaram simulações independentes (1694 padrões, 2 pares) e fizeram cross-analysis.
Ver: **[references/cross-agent-simulation-2026-05-23.md](references/cross-agent-simulation-2026-05-23.md)**

### 5 Correções Aplicadas

| # | Regra | Evidência | Confiança |
|---|-------|-----------|-----------|
| 1 | **BOS REMOVIDO** — 0-12% WR. Structure break = fim do movimento, não entrada | 164 padrões BOS | 0.95 |
| 2 | **FILTRO GAP** — FVG vencedores têm gaps 25-53% maiores. Exigir ≥2.5 pips | WIN gap 3.18p vs LOSS 2.55p | 0.80 |
| 3 | **PREFERÊNCIA BEARISH** — BEARISH_FVG 5-10pp WR maior que BULLISH_FVG | EURUSD 49.7% vs 42.8%, GBPUSD 53.5% vs 45.6% | 0.85 |
| 4 | **GBPUSD PRIMÁRIO** — +40% padrões, +4pp WR, +0.35 PF vs EURUSD | 987 vs 707 padrões | 0.82 |
| 5 | **CHoCH INVIÁVEL M15** — 7 sinais em 60 pair-dias | 2 pares × 30 dias | 0.90 |

### Setup Recomendado
**BEARISH_FVG com gap ≥ 3 pips no GBPUSD M15, SL=5-7 pips, TP=3x SL** (WR 56.9%, PF 3.96)

## Arquivos

- `~/.hermes/scripts/forex_bot_real.py` — bot real CHoCH+FVG M15, executa ordens via MT5 F9
- `~/.hermes/scripts/mt5_direct.py` — executor de ordens no MT5 via xdotool (F9 + Alt+B/S)
- `~/.hermes/scripts/trade_tracker.py` — registra trades em trade_log.json
- `~/.hermes/scripts/trade_closer.py` — health check + sync P&L (CLI: health|close). Wrappers: trade_closer_health.py, trade_closer_close.py
- `~/.hermes/scripts/forex_bot.py` — bot de paper trading (substituído pelo real)
- `~/.hermes/scripts/forex_daily_review.py` — relatório diário mínimo (WR + P&L)
- `~/.hermes/scripts/forex_choch_m15.py` — simulação golden hours (roda local, silencioso)
- `~/.hermes/forex/trade_log.json` — log de trades executados (formato: id, pair, direction, entry, sl, tp, status, pnl, result)
- `~/.hermes/forex/real_state.json` — estado atual: active_trades, history, last_balance
- `~/.hermes/forex/brokers.json` — credenciais de corretoras (OANDA, Exness, XM)
- `~/.hermes/forex/oanda_config.json` — placeholder API OANDA
- **[references/advanced-ict-concepts.md](references/advanced-ict-concepts.md)** — Breaker Blocks, Turtle Soup, Mitigation Blocks — conceitos ICT além do FVG (24/05)
- **[references/order-flow-direction-prediction.md](references/order-flow-direction-prediction.md)** — Delta divergence, CVD, absorption — prevendo direção (24/05)
- **[references/wyckoff-institutional-footprints.md](references/wyckoff-institutional-footprints.md)** — Effort vs Result, Springs, Upthrusts — institucional sem order flow (24/05)
- **[references/research-sources-audit-2026-05-24.md](references/research-sources-audit-2026-05-24.md)** — Auditoria completa das fontes do cérebro: problema, solução, novas fontes (24/05)
- **[references/pipeline-scripts-2026-05-20.md](references/pipeline-scripts-2026-05-20.md)** — pipeline completo, cron jobs, pitfalls
- **[references/backtest-crt-corrigido-2026-05-20.md](references/backtest-crt-corrigido-2026-05-20.md)** — backtest corrigido (FVG ICT 3 velas), comparação antes/depois
- **[references/real-results-may2026.md](references/real-results-may2026.md)** — resultados reais da execução no MT5 (20-21/05/2026)
- **[references/backtest-2026-05-24.md](references/backtest-2026-05-24.md)** — Backtest 24/05: 3225 FVGs, 5 pares. Confirma ranking V4. V4 filter: 83 setups, GBPUSD maior volume (37T, 83.8% WR)
- **[references/cross-agent-simulation-2026-05-23.md](references/cross-agent-simulation-2026-05-23.md)** — Cross-agent: Hermes (EURUSD) + Brain (GBPUSD) — 1694 padrões, 5 correções
- **[references/backtest-v4-confirmation-2026-05-24.md](references/backtest-v4-confirmation-2026-05-24.md)** — Segundo backtest independente (24/05): confirma ranking V4, gap thresholds, bullish vs bearish
- **[references/tradingview-integration.md](references/tradingview-integration.md)** — TradingView como fonte primária (23/05/2026): Google OAuth, Bar Replay, chart analyzer, cron scanner
- **[scripts/ssc_pipeline.py](scripts/ssc_pipeline.py)** — download + transcrição + extração de regras do canal SSC

## OANDA Demo

**Status:** MT5 OANDA demo funcional via Wine + Xvfb :99. Login: 1715539800, Server: OANDA_Global-Demo-1.
**Senha MT5:** `wc0ZO6#p` (não mudou)
**Portal OANDA:** `robertosantos.una@gmail.com` / `wc0ZO6#p2026` — login pendente de captcha manual
**API:** Token OANDA NÃO incluso no email de criação. API REST requer portal login separado.

### Execução de ordens via MT5 (F9 + xdotool)

Método confiável para enviar ordens reais no MT5 rodando em Wine + Xvfb:

```bash
# Abrir ordem via F9 (atalho padrão MT5)
python3 ~/.hermes/scripts/mt5_direct.py buy EUR/USD 1.16279 5.0 5.0

# Fechar todas as posições
python3 ~/.hermes/scripts/mt5_direct.py close_all
```

**Scripts:**
- `~/.hermes/scripts/mt5_direct.py` — executor de ordens via xdotool (F9 + Alt+B/S)
- `~/.hermes/scripts/forex_bot_real.py` — bot real CHoCH+FVG M15 com execução no MT5
- `~/.hermes/scripts/mt5_executor.py` — versão anterior (menos confiável, usar mt5_direct.py)

**Fluxo do mt5_direct.py:**
1. Foca janela MetaTrader no Xvfb :99
2. F9 → janela New Order
3. Ctrl+A + digita símbolo → Enter
4. Tab Tab → Volume → digita 0.01
5. Tab Tab → SL → digita valor
6. Tab → TP → digita valor
7. Alt+B (Buy) ou Alt+S (Sell)
8. Escape fecha janela

**Pitfalls:**
- MT5 log é UTF-16LE — usar `data.decode('utf-16-le')` para ler
- CLI params (`/login /password /server`) NÃO auto-conectam no Wine headless
- Login manual necessário na primeira execução (depois sessão persiste)
- VNC necessário para ver/interagir com MT5 no Xvfb
- ☠️ DEDUP CORRIGIDO (20/05)
- ✅ P&L TRACKING (20/05): check_positions() a cada ciclo verifica se SL/TP foi atingido via preço atual (yahoo 5m). Trades fechados atualizam trade_log com pnl/exit_price/result. Histórico em real_state.json.
- OCR do MT5 não lê números de saldo — saída típica é "2- - +". Para ler dados financeiros do MT5, usar xdotool Ctrl+C no Trade Terminal ou F9+Tab para navegar campos, NÃO OCR.
- **Xvfb sem window manager:** `xdotool windowactivate` falha. Usar `xdotool windowfocus` + enviar teclas
- **Verificação visual:** `vision_engine.py mt5` captura Xvfb + OCR para confirmar estado do MT5 (skill `vision-engine`)
- ✅ TRADE_CLOSER.PY CRIADO (21/05): trade_closer.py — script unificado para health check e sync de P&L. Aceita health ou close como argumento CLI. Como o cron não aceita argumentos no campo script, wrappers separados (trade_closer_health.py, trade_closer_close.py) chamam o script principal com o argumento correto.
- ⚠️ CRON SCRIPT NÃO ACEITA ARGS: O campo script do cronjob espera um path literal — trade_closer.py close é tratado como nome de arquivo. Solução: criar scripts wrapper que chamam o script principal com subprocess.
- ⚠️ DESYNC REAL_STATE vs TRADE_LOG: real_state.json e trade_log.json são atualizados separadamente. Se um trade fecha via SL/TP nativo do MT5 sem passar pelo check_positions(), o estado fica inconsistente. trade_closer.py close reconcilia periodicamente (a cada 10 min).
- ☠️ BOT REAL USA DEMO: O bot forex_bot_real.py tem real no nome mas executa via xdotool na conta que estiver logada no MT5 — verificar se é demo (OANDA 1715539800) antes de depositar.
- **⚠️ YDOTOOL + ABNT2 (23/05):** keyboard layout brasileiro corrompe caracteres especiais (`:` → `Ç`, `/` → `;`). Para digitar URLs, usar `brave-browser 'URL'` diretamente ou navegação CDP (sem digitação). ydotool type só funciona para texto sem caracteres especiais.
- **⚠️ RESEARCH SOURCE STAGNATION (24/05):** Fontes antigas (BabyPips, Investopedia, placeholder video IDs) produziam dados repetitivos. FVGs mesmos números a cada 2h, zero insights novos. Solução: `research_sources.json` completamente substituído — ICT avançado (innercircletrader.net), order flow (ATAS, Bookmap, Trader Dale), Wyckoff (Wyckoff Analytics, NewTraderU), COT/sentiment (Barchart, Myfxbook). Rodar `forex_research_collector.py` após cada atualização de fontes. Ver: **[references/research-sources-audit-2026-05-24.md](references/research-sources-audit-2026-05-24.md)**.

## Display Duplicado (MT5 + VNC)

Ver `references/mt5-vnc-wayland-setup.md` — guia completo para espelhar MT5 do Xvfb :99 via x11vnc para o GNOME/Wayland, incluindo o pitfall do WAYLAND_DISPLAY que bloqueia o x11vnc.
