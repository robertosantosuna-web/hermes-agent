---
name: mt5-vnc-display-setup
description: "Setup de MetaTrader 5 + MetaEditor no Xvfb :99 com VNC para duplicação de vídeo. Usuário vê via VNC, AI interage via xdotool/screenshots."
version: 1.0.0
---

# MT5 + VNC Display Setup

MT5 OANDA Demo + MetaEditor rodando em Wine no display virtual Xvfb :99, espelhado via VNC.

## Comandos

```bash
# Xvfb (já deve estar rodando)
Xvfb :99 -screen 0 1280x720x24 &

# MT5
export WINEPREFIX=~/.wine_mt5 DISPLAY=:99
wine "C:/Program Files/MetaTrader 5/terminal64.exe" /portable /login:1715539800 /password:wc0ZO6#p /server:OANDA_Global-Demo-1 &

# MetaEditor
wine "C:/Program Files/MetaTrader 5/MetaEditor64.exe" &

# VNC (CRÍTICO: unset Wayland)
python3 -c "
import subprocess, os
env = os.environ.copy()
env['DISPLAY'] = ':99'
env.pop('WAYLAND_DISPLAY', None)
env.pop('XDG_SESSION_TYPE', None)
subprocess.Popen(['x11vnc', '-forever', '-shared', '-nopw', '-display', ':99'],
                 start_new_session=True, env=env)
"

# Usuário conecta:
vncviewer localhost:5900
```

## Pitfalls

- `x11vnc` DETECTA Wayland e morre se WAYLAND_DISPLAY estiver setada → unset antes
- CLI params do MT5 (`/login /password /server`) NÃO auto-conectam no Wine headless → precisa xdotool
- xdotool `windowactivate` NÃO funciona sem window manager no Xvfb → usar `windowfocus`
- `pgrep terminal64` não acha processo Wine → usar `ps aux | grep`
- MT5 log é UTF-16LE com null bytes → `data.decode('utf-16-le').replace('\x00', '')`

## Verificação

```bash
ps aux | grep -E "Xvfb|terminal64|MetaEditor|x11vnc" | grep -v grep
ss -tlnp | grep 5900
DISPLAY=:99 xwininfo -root -tree | grep -E "MetaTrader|MetaEditor" | grep -v 1x1
```

### Verificar conexão MT5 (online vs offline)

**Método 1 — OCR do status bar (mais confiável):**
```bash
xwd -display :99 -root | convert - -crop 500x60+1100+660 /tmp/mt5_status.png
convert /tmp/mt5_status.png -resize 300% /tmp/mt5_status_big.png
tesseract /tmp/mt5_status_big.png /tmp/mt5_ocr
cat /tmp/mt5_ocr.txt
```
- `0/0Kb` → OFFLINE (não conectado ao servidor)
- `XX/YYKb` com números > 0 → CONECTADO

**Método 2 — Título da janela:**
```bash
DISPLAY=:99 xdotool getwindowname $(DISPLAY=:99 xdotool search --name MetaTrader | head -1)
```
- Conectado: `MetaTrader 5 - OANDA Global Demo-1 - EURUSD,H1`
- Offline: `MetaTrader 5 - Netting - EURUSD,H1` (só mostra tipo de conta)
