---
name: forex-brokers
description: "Gerenciamento de contas em corretoras forex: OANDA (demo ativa, real bugada), Exness (cadastro preenchido, depósito $10 pendente), MT5 login e operação."
version: 1.0.0
---

# Forex Brokers — Corretoras e Contas

## Contas Ativas

| Corretora | Tipo | Nº Conta | Status | Servidor |
|-----------|------|----------|--------|----------|
| OANDA | Demo | #1715539800 | ✅ Ativa | oanda-demo |
| OANDA | Real | — | ❌ NÃO EXISTE | — |
| Exness | Real | Cadastro preenchido | 🟡 Pendente depósito $10 | exness-real |

**⚠️ CORREÇÃO 22/05:** A "OANDA real bugada" na memória estava errada. NÃO existe conta real OANDA — apenas demo foi criada. O bug era tentar logar em conta que não existe.

## OANDA — Demo (ATIVA)

### Dados
- Conta: #1715539800
- Tipo: Demo
- Servidor: OANDA_Global-Demo-1 (MT5)
- Login: 1715539800
- Senha MT5: `wc0ZO6#p`
- Senha Portal: `wc0ZO6#p2026`
- Email: robertosantos.una@gmail.com
- Saldo inicial: $100,000 (demo)

### Status atual (22/05/2026)
- **MT5 NUNCA conectou.** Status bar mostra 0/0Kb (offline).
- CLI params (`/login /password /server`) não auto-conectam no Wine headless
- Primeiro login requer interação visual (usuário via VNC)
- Bot forex PAUSADO (era paper trading, não real)
- Todos os trades em trade_log.json são simulados via Yahoo Finance

### Como verificar
```bash
cat ~/.hermes/forex/real_state.json
cat ~/.hermes/forex/trade_log.json
```

## OANDA — Real (NÃO EXISTE)

**⚠️ Descoberto 22/05: A conta OANDA real nunca foi criada.** O cadastro de 20/05 foi apenas para conta DEMO. A memória dizia "real bloqueada (bug)" mas o bug era tentar logar numa conta inexistente.

### Como descobrimos
- Email OANDA de 20/05: apenas "Your MT5 Demo account details"
- user_profile.yaml: `conta: "demo"`, `servidor: "OANDA_Global-Demo-1"`
- Nenhum email de boas-vindas de conta real
- Senha no vault: wc0ZO6#p (8 chars — demo, não a senha de 13 chars para real)

### Próximo passo
Criar conta real OANDA ou ativar Exness (cadastro já preenchido).

## LIÇÃO: WR do Backtest vs WR Real

**NUNCA usar WR de backtest como condição de entrada em conta real.**

O bug: `forex_bot_real.py` comparava `cfg['wr']` (valor fixo do backtest, ~67%) em vez do WR real da conta (33%). Resultado: bot abria ordens em todos os pares mesmo com WR real abaixo de 40%.

Correção aplicada (22/05):
- `PAIRS[].wr` → `PAIRS[].backtest_wr` (renomeado para evitar confusão)
- Nova função `get_real_wr(pair)` lê `trade_log.json`
- Nova função `should_trade_pair(pair)` decide com base em WR real
- Regras: par com 3+ trades e WR<40% → bloqueado; agregado <35% → só pares elite (WR≥80%); NZD/USD é o único par liberado atualmente

## Exness — Principal Alternativa

### Status
Cadastro preenchido. Falta apenas:
1. Depositar $10 (mínimo)
2. Configurar MT5 com servidor Exness
3. Migrar bot forex para conta Exness

### Dados
- Email: robertosantos.una@gmail.com
- Servidor MT5: Exness-Real (a confirmar)
- Depósito mínimo: $10 (recomendado $50-100 para operar)

### Procedimento de Ativação

1. Depositar $10 via:
   - Pix (instantâneo, preferencial)
   - Cartão de crédito
   - Cripto (USDT)

2. Baixar/Configurar MT5 Exness:
```bash
# MT5 já instalado via Wine em:
# ~/.wine/drive_c/Program Files/MetaTrader 5/
# MetaEditor em:
# ~/.wine/drive_c/Program Files/MetaTrader 5/MetaEditor.exe
```

3. Login no MT5 Exness:
   - Servidor: Exness-Real (ou Exness-Demo para teste)
   - Login: [conta Exness]
   - Senha: [definida no cadastro]

4. Atualizar bot forex:
```bash
# Editar ~/.hermes/scripts/forex_bot_real.py
# Alterar servidor e credenciais para Exness
```

## MT5 — Operação Técnica

### Localização
```
~/.wine/drive_c/Program Files/MetaTrader 5/terminal64.exe
```

### Interação via xdotool
```bash
# Encontrar janela MT5
xdotool search --name "MetaTrader 5"

# Enviar teclas
xdotool key --window <WINDOW_ID> F9  # Nova ordem
xdotool type --window <WINDOW_ID> "EURUSD"
```

### Interação via Desktop Daemon
```json
{"action": "screenshot"}
{"action": "mouse_move", "x": 100, "y": 200}
{"action": "mouse_click"}
```

### Xvfb + VNC
Ver skill `mt5-vnc-display-setup` para compartilhar tela com Roberto.

## Migração do Bot (OANDA → Exness)

Quando a conta Exness estiver ativa:

1. Copiar estratégia atual:
```bash
cp ~/.hermes/scripts/forex_bot_real.py ~/.hermes/scripts/forex_bot_exness.py
```

2. Editar credenciais:
```python
BROKER = "exness"
SERVER = "Exness-Real"
LOGIN = "<conta_exness>"
PASSWORD = "<senha_exness>"
```

3. Atualizar cronjob:
```
cronjob(action="update", job_id="21f7caf29606", ...)
```

4. Testar com 1 trade antes de ativar 24h.

## Regras de Operação

- Máximo 3 posições simultâneas
- Fechar todas antes do fechamento do mercado (sexta 17h)
- WR ≥ 40% → RR mínimo 3:1
- WR ≥ 80% → RR livre
- WR < 40% → NÃO abrir ordem
- Self-learning ajusta parâmetros automaticamente

## Referências

- Estratégia: `skill forex-choch-m15`
- Trade log: `~/.hermes/forex/trade_log.json`
- Estado real: `~/.hermes/forex/real_state.json`
- Bot script: `~/.hermes/scripts/forex_bot_real.py`
